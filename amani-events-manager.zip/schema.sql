-- Tables de base
CREATE TABLE IF NOT EXISTS admins (
    id TEXT PRIMARY KEY,
    email TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL,
    name TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS clients (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    email TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL,
    is_temporary_password INTEGER DEFAULT 1,
    status TEXT DEFAULT 'active',
    last_login DATETIME,
    reset_token TEXT,
    reset_token_expires DATETIME,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS collaborators (
    id TEXT PRIMARY KEY,
    client_id TEXT NOT NULL,
    email TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL,
    name TEXT NOT NULL,
    role TEXT,
    is_temporary_password INTEGER DEFAULT 1,
    status TEXT DEFAULT 'active',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (client_id) REFERENCES clients(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS client_modules (
    client_id TEXT NOT NULL,
    module_name TEXT NOT NULL,
    is_active INTEGER DEFAULT 0,
    PRIMARY KEY (client_id, module_name),
    FOREIGN KEY (client_id) REFERENCES clients(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS collaborator_permissions (
    collaborator_id TEXT NOT NULL,
    module_name TEXT NOT NULL,
    can_access INTEGER DEFAULT 0,
    PRIMARY KEY (collaborator_id, module_name),
    FOREIGN KEY (collaborator_id) REFERENCES collaborators(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS password_resets (
    email TEXT NOT NULL,
    token TEXT PRIMARY KEY,
    expires_at DATETIME NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Tables des modules (toutes liées à client_id)
CREATE TABLE IF NOT EXISTS planning (
    id TEXT PRIMARY KEY,
    client_id TEXT NOT NULL,
    title TEXT NOT NULL,
    description TEXT,
    start_date DATETIME NOT NULL,
    end_date DATETIME NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (client_id) REFERENCES clients(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS evenementiel_calendars (
    id TEXT PRIMARY KEY,
    client_id TEXT NOT NULL,
    month INTEGER NOT NULL,
    year INTEGER NOT NULL,
    status TEXT DEFAULT 'OPEN' CHECK(status IN ('OPEN', 'ARCHIVED')),
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (client_id) REFERENCES clients(id) ON DELETE CASCADE,
    UNIQUE(client_id, month, year)
);

CREATE TABLE IF NOT EXISTS evenementiel_spaces (
    id TEXT PRIMARY KEY,
    client_id TEXT NOT NULL,
    name TEXT NOT NULL,
    color TEXT NOT NULL, -- Hex color
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (client_id) REFERENCES clients(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS evenementiel_staff_types (
    id TEXT PRIMARY KEY,
    client_id TEXT NOT NULL,
    name TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (client_id) REFERENCES clients(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS evenementiel (
    id TEXT PRIMARY KEY,
    client_id TEXT NOT NULL,
    calendar_id TEXT NOT NULL,
    type TEXT NOT NULL CHECK(type IN ('PRIVÉ', 'PROFESSIONNEL')),
    -- Champs communs
    phone TEXT NOT NULL,
    email TEXT,
    address TEXT,
    start_time DATETIME NOT NULL,
    end_time DATETIME NOT NULL,
    num_people INTEGER,
    documents TEXT, -- JSON string
    -- Champs PRIVÉ
    first_name TEXT,
    last_name TEXT,
    -- Champs PROFESSIONNEL
    company_name TEXT,
    organizer_name TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (client_id) REFERENCES clients(id) ON DELETE CASCADE,
    FOREIGN KEY (calendar_id) REFERENCES evenementiel_calendars(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS evenementiel_event_spaces (
    event_id TEXT NOT NULL,
    space_id TEXT NOT NULL,
    PRIMARY KEY (event_id, space_id),
    FOREIGN KEY (event_id) REFERENCES evenementiel(id) ON DELETE CASCADE,
    FOREIGN KEY (space_id) REFERENCES evenementiel_spaces(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS evenementiel_event_staff (
    event_id TEXT NOT NULL,
    staff_type_id TEXT NOT NULL,
    count INTEGER NOT NULL,
    PRIMARY KEY (event_id, staff_type_id),
    FOREIGN KEY (event_id) REFERENCES evenementiel(id) ON DELETE CASCADE,
    FOREIGN KEY (staff_type_id) REFERENCES evenementiel_staff_types(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS facture (
    id TEXT PRIMARY KEY,
    client_id TEXT NOT NULL,
    invoice_number TEXT NOT NULL,
    customer_name TEXT NOT NULL,
    amount REAL NOT NULL,
    status TEXT DEFAULT 'pending',
    due_date DATETIME,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (client_id) REFERENCES clients(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS employes (
    id TEXT PRIMARY KEY,
    client_id TEXT NOT NULL,
    first_name TEXT NOT NULL,
    last_name TEXT NOT NULL,
    email TEXT,
    position TEXT,
    salary REAL,
    hire_date DATE,
    tags TEXT, -- JSON array of tags/skills
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (client_id) REFERENCES clients(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS crm_contacts (
    id TEXT PRIMARY KEY,
    client_id TEXT NOT NULL,
    type TEXT NOT NULL CHECK(type IN ('PRIVÉ', 'PROFESSIONNEL')),
    first_name TEXT,
    last_name TEXT,
    company_name TEXT,
    organizer_name TEXT,
    email TEXT,
    phone TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (client_id) REFERENCES clients(id) ON DELETE CASCADE,
    UNIQUE(client_id, phone)
);

CREATE TABLE IF NOT EXISTS evenementiel_event_assignments (
    event_id TEXT NOT NULL,
    employee_id TEXT NOT NULL,
    staff_type_id TEXT NOT NULL,
    PRIMARY KEY (event_id, employee_id),
    FOREIGN KEY (event_id) REFERENCES evenementiel(id) ON DELETE CASCADE,
    FOREIGN KEY (employee_id) REFERENCES employes(id) ON DELETE CASCADE,
    FOREIGN KEY (staff_type_id) REFERENCES evenementiel_staff_types(id) ON DELETE CASCADE
);

-- Indexes pour la performance multi-tenant
CREATE INDEX IF NOT EXISTS idx_collaborators_client_id ON collaborators(client_id);
CREATE INDEX IF NOT EXISTS idx_client_modules_client_id ON client_modules(client_id);
CREATE INDEX IF NOT EXISTS idx_planning_client_id ON planning(client_id);
CREATE INDEX IF NOT EXISTS idx_evenementiel_client_id ON evenementiel(client_id);
CREATE INDEX IF NOT EXISTS idx_facture_client_id ON facture(client_id);
CREATE INDEX IF NOT EXISTS idx_employes_client_id ON employes(client_id);
CREATE INDEX IF NOT EXISTS idx_crm_contacts_client_id ON crm_contacts(client_id);
CREATE INDEX IF NOT EXISTS idx_evenementiel_calendar_id ON evenementiel(calendar_id);
