import React, { useState, useEffect } from 'react';
import { moduleApi } from '../../lib/api';
import { 
    Calendar as CalendarIcon, 
    Plus, 
    Archive, 
    Clock, 
    Users, 
    MapPin, 
    ChevronRight,
    AlertCircle,
    CheckCircle2,
    History,
    X,
    Building2,
    User,
    UserCheck,
    Phone,
    Mail
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { EventForm } from './EventForm';
import { MonthlyCalendar } from './MonthlyCalendar';

interface Calendar {
    id: string;
    month: number;
    year: number;
    status: 'OPEN' | 'ARCHIVED';
    created_at: string;
}

const MONTHS = [
    'Janvier', 'Février', 'Mars', 'Avril', 'Mai', 'Juin',
    'Juillet', 'Août', 'Septembre', 'Octobre', 'Novembre', 'Décembre'
];

export const EvenementielModule = () => {
    const [calendars, setCalendars] = useState<Calendar[]>([]);
    const [selectedCalendar, setSelectedCalendar] = useState<Calendar | null>(null);
    const [events, setEvents] = useState<any[]>([]);
    const [loading, setLoading] = useState(true);
    const [showEventForm, setShowEventForm] = useState(false);
    const [showNewCalendarModal, setShowNewCalendarModal] = useState(false);
    const [selectedEvent, setSelectedEvent] = useState<any | null>(null);
    const [newCalendar, setNewCalendar] = useState({ month: new Date().getMonth() + 1, year: new Date().getFullYear() });

    useEffect(() => {
        loadCalendars();
    }, []);

    useEffect(() => {
        if (selectedCalendar) {
            loadEvents(selectedCalendar.id);
        }
    }, [selectedCalendar]);

    const loadCalendars = async () => {
        setLoading(true);
        try {
            const data = await moduleApi.getEvenementielCalendars();
            setCalendars(data);
            if (data.length > 0 && !selectedCalendar) {
                setSelectedCalendar(data[0]);
            }
        } catch (e) {
            console.error(e);
        } finally {
            setLoading(false);
        }
    };

    const loadEvents = async (id: string) => {
        try {
            const data = await moduleApi.getEvenementielCalendarEvents(id);
            setEvents(data);
        } catch (e) {
            console.error(e);
        }
    };

    const handleCreateCalendar = async (e: React.FormEvent) => {
        e.preventDefault();
        try {
            await moduleApi.createEvenementielCalendar(newCalendar);
            setShowNewCalendarModal(false);
            loadCalendars();
        } catch (e: any) {
            alert(e.message);
        }
    };

    const handleMonthChange = (month: number, year: number) => {
        const cal = calendars.find(c => c.month === month && c.year === year);
        if (cal) {
            setSelectedCalendar(cal);
        } else {
            setNewCalendar({ month, year });
            setShowNewCalendarModal(true);
        }
    };

    return (
        <div className="space-y-10">
            <header className="flex items-center justify-between">
                <div>
                    <h1 className="text-3xl font-bold text-white tracking-tight">Module Événementiel</h1>
                    <p className="text-gray-500 mt-1">
                        Gérez vos privatisations et votre staffing
                        {selectedCalendar && (
                            <span className="ml-2 text-[10px] bg-white/5 px-2 py-0.5 rounded border border-white/5">
                                Créé le {new Date(selectedCalendar.created_at).toLocaleDateString('fr-FR', { day: 'numeric', month: 'long', year: 'numeric' })}
                            </span>
                        )}
                    </p>
                </div>
                <div className="flex gap-4">
                    <button 
                        onClick={() => setShowNewCalendarModal(true)}
                        className="flex items-center gap-2 px-6 py-3 bg-white/5 border border-white/10 rounded-xl text-white font-bold hover:bg-white/10 transition-all"
                    >
                        <CalendarIcon size={20} />
                        <span>Nouveau Calendrier</span>
                    </button>
                    {selectedCalendar && selectedCalendar.status === 'OPEN' && (
                        <button 
                            onClick={() => setShowEventForm(true)}
                            className="flex items-center gap-2 px-6 py-3 bg-white text-black rounded-xl font-bold hover:bg-gray-200 transition-all shadow-lg shadow-white/5"
                        >
                            <Plus size={20} />
                            <span>Nouvelle Privatisation</span>
                        </button>
                    )}
                </div>
            </header>

            {/* Calendar Selector (Mini) */}
            <div className="flex gap-2 overflow-x-auto pb-4 scrollbar-hide">
                {calendars.map(cal => (
                    <button
                        key={cal.id}
                        onClick={() => setSelectedCalendar(cal)}
                        className={`flex-shrink-0 px-4 py-2 rounded-xl border transition-all text-xs font-bold ${
                            selectedCalendar?.id === cal.id 
                                ? 'bg-white border-white text-black shadow-lg' 
                                : 'bg-[#111111] border-white/5 text-gray-500 hover:border-white/20'
                        }`}
                    >
                        {MONTHS[cal.month - 1]} {cal.year}
                    </button>
                ))}
            </div>

            {/* Main Calendar View */}
            {selectedCalendar ? (
                <MonthlyCalendar 
                    month={selectedCalendar.month}
                    year={selectedCalendar.year}
                    events={events}
                    onMonthChange={handleMonthChange}
                    onEventClick={setSelectedEvent}
                />
            ) : (
                <div className="py-40 text-center bg-[#111111] rounded-3xl border border-dashed border-white/10">
                    <CalendarIcon size={48} className="text-gray-700 mx-auto mb-4" />
                    <p className="text-gray-500 font-medium">Sélectionnez ou créez un calendrier pour commencer</p>
                </div>
            )}

            {/* Modals */}
            <AnimatePresence>
                {showEventForm && selectedCalendar && (
                    <EventForm 
                        calendarId={selectedCalendar.id}
                        month={selectedCalendar.month}
                        year={selectedCalendar.year}
                        onClose={() => setShowEventForm(false)}
                        onSuccess={() => {
                            setShowEventForm(false);
                            loadEvents(selectedCalendar.id);
                        }}
                    />
                )}

                {selectedEvent && (
                    <div className="fixed inset-0 bg-black/90 backdrop-blur-md z-50 flex items-center justify-center p-6">
                        <motion.div 
                            initial={{ opacity: 0, scale: 0.95 }}
                            animate={{ opacity: 1, scale: 1 }}
                            exit={{ opacity: 0, scale: 0.95 }}
                            className="w-full max-w-2xl bg-[#0A0A0A] rounded-3xl border border-white/10 overflow-hidden shadow-2xl"
                        >
                            <div className="p-8 border-b border-white/5 flex items-center justify-between bg-[#111111]">
                                <div className="flex items-center gap-4">
                                    <div className="w-12 h-12 bg-white/5 rounded-2xl flex items-center justify-center">
                                        {selectedEvent.type === 'PRIVÉ' ? <User className="text-white" /> : <Building2 className="text-white" />}
                                    </div>
                                    <div>
                                        {/* 1. NOM PRENOM/ENTREPRISE */}
                                        <h2 className="text-2xl font-bold text-white">
                                            {selectedEvent.type === 'PRIVÉ' ? `${selectedEvent.first_name} ${selectedEvent.last_name}` : selectedEvent.company_name}
                                        </h2>
                                        {/* 2. NOMBRE DE PERSONNES */}
                                        <p className="text-gray-500 text-sm flex items-center gap-2 mt-1">
                                            <Users size={14} />
                                            {selectedEvent.num_people} personnes • {selectedEvent.type}
                                        </p>
                                    </div>
                                </div>
                                <button onClick={() => setSelectedEvent(null)} className="p-2 hover:bg-white/5 rounded-full text-gray-400">
                                    <X size={24} />
                                </button>
                            </div>

                            <div className="p-8 space-y-8">
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                                    {/* 3. HEURE DEBUT ET HEURE FIN */}
                                    <div className="space-y-4">
                                        <h3 className="text-[10px] font-bold text-gray-500 uppercase tracking-widest flex items-center gap-2">
                                            <Clock size={14} /> Horaires
                                        </h3>
                                        <div className="p-4 bg-white/5 rounded-2xl border border-white/5">
                                            <div className="flex items-center justify-between text-white">
                                                <span className="text-gray-500 text-xs">Début</span>
                                                <span className="font-bold">{new Date(selectedEvent.start_time).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                                            </div>
                                            <div className="flex items-center justify-between text-white mt-2">
                                                <span className="text-gray-500 text-xs">Fin</span>
                                                <span className="font-bold">{new Date(selectedEvent.end_time).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                                            </div>
                                            <div className="mt-3 pt-3 border-t border-white/5 text-[10px] text-gray-500 font-bold uppercase tracking-wider">
                                                {new Date(selectedEvent.start_time).toLocaleDateString([], { day: 'numeric', month: 'long', year: 'numeric' })}
                                            </div>
                                        </div>
                                    </div>

                                    <div className="space-y-4">
                                        <h3 className="text-[10px] font-bold text-gray-500 uppercase tracking-widest flex items-center gap-2">
                                            <MapPin size={14} /> Espaces
                                        </h3>
                                        <div className="flex flex-wrap gap-2">
                                            {selectedEvent.spaces?.map((s: any) => (
                                                <span key={s.id} className="px-3 py-1.5 rounded-xl bg-white/5 text-xs font-bold border border-white/5" style={{ color: s.color }}>
                                                    {s.name}
                                                </span>
                                            ))}
                                        </div>
                                    </div>
                                </div>

                                <div className="space-y-6">
                                    <h3 className="text-[10px] font-bold text-gray-500 uppercase tracking-widest">Staffing & Assignments</h3>
                                    <div className="space-y-4">
                                        {selectedEvent.staff?.map((s: any, idx: number) => {
                                            const assignments = selectedEvent.assignments?.filter((a: any) => a.staff_type_id === s.staff_type_id) || [];
                                            const extras = Math.max(0, s.count - assignments.length);

                                            return (
                                                <div key={idx} className="bg-white/[0.02] rounded-2xl p-6 border border-white/5 space-y-4">
                                                    <div className="flex items-center justify-between">
                                                        <span className="font-bold text-white text-lg">{s.name}</span>
                                                        <div className="flex items-center gap-2 px-3 py-1 bg-white/5 rounded-lg text-xs font-bold text-gray-400">
                                                            Besoin: {s.count}
                                                        </div>
                                                    </div>

                                                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                                        {/* 4. HÔTESSE INTERNE BOOKER */}
                                                        <div className="space-y-2">
                                                            <p className="text-[10px] font-bold text-gray-600 uppercase tracking-widest">Internes Booker</p>
                                                            <div className="flex flex-wrap gap-2">
                                                                {assignments.length > 0 ? assignments.map((a: any, i: number) => (
                                                                    <div key={i} className="flex items-center gap-2 px-3 py-1.5 bg-blue-500/10 text-blue-400 rounded-xl text-[10px] font-bold border border-blue-500/20">
                                                                        <UserCheck size={12} />
                                                                        {a.employee_name}
                                                                    </div>
                                                                )) : (
                                                                    <span className="text-gray-600 text-[10px] font-bold italic">Aucun interne</span>
                                                                )}
                                                            </div>
                                                        </div>

                                                        {/* 5. NOMBRE D'HOTESSE EN EXTRA */}
                                                        <div className="space-y-2">
                                                            <p className="text-[10px] font-bold text-gray-600 uppercase tracking-widest">Extras à prévoir</p>
                                                            <div className={`inline-flex items-center justify-center px-4 py-1.5 rounded-xl font-bold text-sm ${extras > 0 ? 'bg-orange-500/10 text-orange-400 border border-orange-500/20' : 'bg-green-500/10 text-green-400 border border-green-500/20'}`}>
                                                                {extras} {extras > 1 ? 'Extras' : 'Extra'}
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            );
                                        })}
                                    </div>
                                </div>
                            </div>

                            <div className="p-8 bg-[#111111] border-t border-white/5 flex justify-end gap-4">
                                <button 
                                    onClick={() => setSelectedEvent(null)}
                                    className="px-6 py-3 rounded-xl font-bold border border-white/10 text-white hover:bg-white/5 transition-all"
                                >
                                    Fermer
                                </button>
                                <button 
                                    className="px-6 py-3 bg-white text-black rounded-xl font-bold hover:bg-gray-200 transition-all"
                                >
                                    Modifier
                                </button>
                            </div>
                        </motion.div>
                    </div>
                )}

                {showNewCalendarModal && (
                    <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-6">
                        <motion.div 
                            initial={{ opacity: 0, scale: 0.95 }}
                            animate={{ opacity: 1, scale: 1 }}
                            exit={{ opacity: 0, scale: 0.95 }}
                            className="w-full max-w-md bg-[#111111] rounded-2xl p-10 border border-white/5 shadow-2xl"
                        >
                            <h2 className="text-2xl font-bold text-white mb-8">Nouveau Calendrier</h2>
                            <form onSubmit={handleCreateCalendar} className="space-y-6">
                                <div className="space-y-2">
                                    <label className="text-[10px] font-bold text-gray-500 uppercase tracking-widest">Mois</label>
                                    <select 
                                        value={newCalendar.month}
                                        onChange={e => setNewCalendar({...newCalendar, month: parseInt(e.target.value)})}
                                        className="w-full bg-black border border-white/10 rounded-lg px-4 py-3 text-white outline-none focus:border-white transition-all"
                                    >
                                        {MONTHS.map((m, i) => <option key={i} value={i + 1}>{m}</option>)}
                                    </select>
                                </div>
                                <div className="space-y-2">
                                    <label className="text-[10px] font-bold text-gray-500 uppercase tracking-widest">Année</label>
                                    <input 
                                        type="number"
                                        value={newCalendar.year}
                                        onChange={e => setNewCalendar({...newCalendar, year: parseInt(e.target.value)})}
                                        className="w-full bg-black border border-white/10 rounded-lg px-4 py-3 text-white outline-none focus:border-white transition-all"
                                    />
                                </div>
                                <div className="flex gap-4 pt-4">
                                    <button 
                                        type="button"
                                        onClick={() => setShowNewCalendarModal(false)}
                                        className="flex-1 px-6 py-4 rounded-xl font-bold border border-white/10 text-white hover:bg-white/5 transition-all"
                                    >
                                        Annuler
                                    </button>
                                    <button 
                                        type="submit"
                                        className="flex-1 bg-white text-black px-6 py-4 rounded-xl font-bold hover:bg-gray-200 transition-all shadow-xl shadow-white/5"
                                    >
                                        Créer
                                    </button>
                                </div>
                            </form>
                        </motion.div>
                    </div>
                )}
            </AnimatePresence>
        </div>
    );
};
