import React, { useState, useEffect } from 'react';
import { moduleApi } from '../../lib/api';
import { X, Users, MapPin, Clock, CheckCircle2, AlertCircle, User, Building2, Phone, Mail } from 'lucide-react';
import { motion } from 'motion/react';

interface Props {
    calendarId: string;
    month: number;
    year: number;
    onClose: () => void;
    onSuccess: () => void;
}

interface StaffingRequirement {
    staffTypeId: string;
    staffTypeName: string;
    needed: number;
    assignedEmployeeIds: string[];
}

export const EventForm = ({ calendarId, month, year, onClose, onSuccess }: Props) => {
    const [type, setType] = useState<'PRIVÉ' | 'PROFESSIONNEL'>('PRIVÉ');
    
    // Calculate min and max dates for the month
    const minDate = `${year}-${String(month).padStart(2, '0')}-01`;
    const lastDay = new Date(year, month, 0).getDate();
    const maxDate = `${year}-${String(month).padStart(2, '0')}-${String(lastDay).padStart(2, '0')}`;

    // Default date: today if it's in the month, otherwise the first of the month
    const getDefaultDate = () => {
        const today = new Date();
        if (today.getFullYear() === year && today.getMonth() + 1 === month) {
            return today.toISOString().split('T')[0];
        }
        return minDate;
    };

    const [formData, setFormData] = useState({
        firstName: '',
        lastName: '',
        companyName: '',
        organizerName: '',
        phone: '',
        email: '',
        date: getDefaultDate(),
        startTime: '19:00',
        endTime: '02:00',
        numPeople: '',
        selectedSpaceIds: [] as string[]
    });

    const [spaces, setSpaces] = useState<any[]>([]);
    const [staffTypes, setStaffTypes] = useState<any[]>([]);
    const [employees, setEmployees] = useState<any[]>([]);
    const [staffingRequirements, setStaffingRequirements] = useState<StaffingRequirement[]>([]);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState('');

    useEffect(() => {
        loadData();
    }, []);

    const loadData = async () => {
        try {
            const [s, st, e] = await Promise.all([
                moduleApi.getEvenementielSpaces(),
                moduleApi.getEvenementielStaffTypes(),
                moduleApi.getEmployes()
            ]);
            setSpaces(s);
            setStaffTypes(st);
            setEmployees(e);
            
            setStaffingRequirements(st.map((type: any) => ({
                staffTypeId: type.id,
                staffTypeName: type.name,
                needed: 0,
                assignedEmployeeIds: []
            })));
        } catch (err) {
            console.error(err);
        }
    };

    const toggleSpace = (id: string) => {
        setFormData(prev => ({
            ...prev,
            selectedSpaceIds: prev.selectedSpaceIds.includes(id)
                ? prev.selectedSpaceIds.filter(sid => sid !== id)
                : [...prev.selectedSpaceIds, id]
        }));
    };

    const updateStaffingNeed = (staffTypeId: string, needed: number) => {
        setStaffingRequirements(prev => prev.map(req => 
            req.staffTypeId === staffTypeId ? { ...req, needed } : req
        ));
    };

    const toggleAssignment = (employeeId: string, staffTypeId: string) => {
        setStaffingRequirements(prev => prev.map(req => {
            if (req.staffTypeId === staffTypeId) {
                const isAssigned = req.assignedEmployeeIds.includes(employeeId);
                return {
                    ...req,
                    assignedEmployeeIds: isAssigned
                        ? req.assignedEmployeeIds.filter(id => id !== employeeId)
                        : [...req.assignedEmployeeIds, employeeId]
                };
            }
            return req;
        }));
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setLoading(true);
        setError('');
        try {
            const staff_requests: Record<string, number> = {};
            const assignments: any[] = [];

            staffingRequirements.forEach(req => {
                if (req.needed > 0) {
                    staff_requests[req.staffTypeId] = req.needed;
                    req.assignedEmployeeIds.forEach(empId => {
                        assignments.push({ employee_id: empId, staff_type_id: req.staffTypeId });
                    });
                }
            });

            // Combine date and times
            const start_time = `${formData.date}T${formData.startTime}:00`;
            let end_time = `${formData.date}T${formData.endTime}:00`;

            // If end time is earlier than start time, assume it's the next day
            if (formData.endTime < formData.startTime) {
                const endDate = new Date(formData.date);
                endDate.setDate(endDate.getDate() + 1);
                end_time = `${endDate.toISOString().split('T')[0]}T${formData.endTime}:00`;
            }

            await moduleApi.createEvenementiel({
                calendar_id: calendarId,
                type,
                phone: formData.phone,
                email: formData.email,
                first_name: formData.firstName,
                last_name: formData.lastName,
                company_name: formData.companyName,
                organizer_name: formData.organizerName,
                start_time,
                end_time,
                num_people: parseInt(formData.numPeople) || 0,
                space_ids: formData.selectedSpaceIds,
                staff_requests,
                assignments
            });
            onSuccess();
        } catch (err: any) {
            setError(err.message);
        } finally {
            setLoading(false);
        }
    };

    const totalExtras = staffingRequirements.reduce((acc, req) => {
        return acc + Math.max(0, req.needed - req.assignedEmployeeIds.length);
    }, 0);

    return (
        <div className="fixed inset-0 bg-black/90 backdrop-blur-md z-50 flex items-center justify-center p-6 overflow-y-auto">
            <motion.div 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="w-full max-w-4xl bg-[#0A0A0A] rounded-3xl border border-white/10 shadow-2xl overflow-hidden my-auto"
            >
                {/* Header */}
                <div className="p-8 border-b border-white/5 flex items-center justify-between bg-[#111111]">
                    <div>
                        <h2 className="text-2xl font-bold text-white">Nouvelle Privatisation</h2>
                        <div className="flex gap-4 mt-2">
                            <button 
                                onClick={() => setType('PRIVÉ')}
                                className={`text-xs font-bold uppercase tracking-widest pb-1 border-b-2 transition-all ${type === 'PRIVÉ' ? 'border-white text-white' : 'border-transparent text-gray-500'}`}
                            >
                                Particulier
                            </button>
                            <button 
                                onClick={() => setType('PROFESSIONNEL')}
                                className={`text-xs font-bold uppercase tracking-widest pb-1 border-b-2 transition-all ${type === 'PROFESSIONNEL' ? 'border-white text-white' : 'border-transparent text-gray-500'}`}
                            >
                                Professionnel
                            </button>
                        </div>
                    </div>
                    <button onClick={onClose} className="p-2 hover:bg-white/5 rounded-full text-gray-400">
                        <X size={24} />
                    </button>
                </div>

                <form onSubmit={handleSubmit} className="p-8 space-y-10">
                    {error && (
                        <div className="p-4 bg-red-500/10 border border-red-500/20 text-red-400 rounded-xl flex items-center gap-3">
                            <AlertCircle size={20} />
                            <p className="text-sm font-medium">{error}</p>
                        </div>
                    )}

                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
                        {/* Left Column: Info & Logistics */}
                        <div className="space-y-8">
                            <section className="space-y-4">
                                <h3 className="text-[10px] font-bold text-gray-500 uppercase tracking-widest flex items-center gap-2">
                                    <User size={14} /> Informations Client
                                </h3>
                                <div className="grid grid-cols-2 gap-4">
                                    {type === 'PRIVÉ' ? (
                                        <>
                                            <div className="space-y-2">
                                                <label className="text-[10px] font-bold text-gray-600 uppercase tracking-widest">Prénom</label>
                                                <input 
                                                    type="text" required
                                                    value={formData.firstName}
                                                    onChange={e => setFormData({...formData, firstName: e.target.value})}
                                                    className="w-full bg-black border border-white/10 rounded-xl px-4 py-3 text-white outline-none focus:border-white transition-all"
                                                />
                                            </div>
                                            <div className="space-y-2">
                                                <label className="text-[10px] font-bold text-gray-600 uppercase tracking-widest">Nom</label>
                                                <input 
                                                    type="text" required
                                                    value={formData.lastName}
                                                    onChange={e => setFormData({...formData, lastName: e.target.value})}
                                                    className="w-full bg-black border border-white/10 rounded-xl px-4 py-3 text-white outline-none focus:border-white transition-all"
                                                />
                                            </div>
                                        </>
                                    ) : (
                                        <>
                                            <div className="space-y-2">
                                                <label className="text-[10px] font-bold text-gray-600 uppercase tracking-widest">Entreprise</label>
                                                <input 
                                                    type="text" required
                                                    value={formData.companyName}
                                                    onChange={e => setFormData({...formData, companyName: e.target.value})}
                                                    className="w-full bg-black border border-white/10 rounded-xl px-4 py-3 text-white outline-none focus:border-white transition-all"
                                                />
                                            </div>
                                            <div className="space-y-2">
                                                <label className="text-[10px] font-bold text-gray-600 uppercase tracking-widest">Organisateur</label>
                                                <input 
                                                    type="text" required
                                                    value={formData.organizerName}
                                                    onChange={e => setFormData({...formData, organizerName: e.target.value})}
                                                    className="w-full bg-black border border-white/10 rounded-xl px-4 py-3 text-white outline-none focus:border-white transition-all"
                                                />
                                            </div>
                                        </>
                                    )}
                                    <div className="space-y-2">
                                        <label className="text-[10px] font-bold text-gray-600 uppercase tracking-widest">Téléphone</label>
                                        <input 
                                            type="tel" required
                                            value={formData.phone}
                                            onChange={e => setFormData({...formData, phone: e.target.value})}
                                            className="w-full bg-black border border-white/10 rounded-xl px-4 py-3 text-white outline-none focus:border-white transition-all"
                                        />
                                    </div>
                                    <div className="space-y-2">
                                        <label className="text-[10px] font-bold text-gray-600 uppercase tracking-widest">Email</label>
                                        <input 
                                            type="email"
                                            value={formData.email}
                                            onChange={e => setFormData({...formData, email: e.target.value})}
                                            className="w-full bg-black border border-white/10 rounded-xl px-4 py-3 text-white outline-none focus:border-white transition-all"
                                        />
                                    </div>
                                </div>
                            </section>

                            <section className="space-y-4">
                                <h3 className="text-[10px] font-bold text-gray-500 uppercase tracking-widest flex items-center gap-2">
                                    <Clock size={14} /> Logistique
                                </h3>
                                <div className="grid grid-cols-2 gap-4">
                                    <div className="space-y-2 col-span-2">
                                        <label className="text-[10px] font-bold text-gray-600 uppercase tracking-widest">Date de l'événement</label>
                                        <input 
                                            type="date" required
                                            min={minDate}
                                            max={maxDate}
                                            value={formData.date}
                                            onChange={e => setFormData({...formData, date: e.target.value})}
                                            className="w-full bg-black border border-white/10 rounded-xl px-4 py-3 text-white outline-none focus:border-white transition-all"
                                        />
                                    </div>
                                    <div className="space-y-2">
                                        <label className="text-[10px] font-bold text-gray-600 uppercase tracking-widest">Heure de début</label>
                                        <input 
                                            type="time" required
                                            value={formData.startTime}
                                            onChange={e => setFormData({...formData, startTime: e.target.value})}
                                            className="w-full bg-black border border-white/10 rounded-xl px-4 py-3 text-white outline-none focus:border-white transition-all"
                                        />
                                    </div>
                                    <div className="space-y-2">
                                        <label className="text-[10px] font-bold text-gray-600 uppercase tracking-widest">Heure de fin</label>
                                        <input 
                                            type="time" required
                                            value={formData.endTime}
                                            onChange={e => setFormData({...formData, endTime: e.target.value})}
                                            className="w-full bg-black border border-white/10 rounded-xl px-4 py-3 text-white outline-none focus:border-white transition-all"
                                        />
                                    </div>
                                    <div className="space-y-2 col-span-2">
                                        <label className="text-[10px] font-bold text-gray-600 uppercase tracking-widest">Nombre de personnes</label>
                                        <input 
                                            type="number" required
                                            value={formData.numPeople}
                                            onChange={e => setFormData({...formData, numPeople: e.target.value})}
                                            className="w-full bg-black border border-white/10 rounded-xl px-4 py-3 text-white outline-none focus:border-white transition-all"
                                        />
                                    </div>
                                </div>
                            </section>

                            <section className="space-y-4">
                                <h3 className="text-[10px] font-bold text-gray-500 uppercase tracking-widest flex items-center gap-2">
                                    <MapPin size={14} /> Espaces
                                </h3>
                                <div className="flex flex-wrap gap-3">
                                    {spaces.map(space => (
                                        <button
                                            key={space.id}
                                            type="button"
                                            onClick={() => toggleSpace(space.id)}
                                            className={`px-4 py-2 rounded-xl border transition-all text-sm font-bold flex items-center gap-2 ${
                                                formData.selectedSpaceIds.includes(space.id)
                                                    ? 'bg-white border-white text-black'
                                                    : 'bg-black border-white/10 text-gray-500 hover:border-white/30'
                                            }`}
                                        >
                                            <div className="w-2 h-2 rounded-full" style={{ backgroundColor: space.color }} />
                                            {space.name}
                                        </button>
                                    ))}
                                </div>
                            </section>
                        </div>


                        {/* Right Column: Staffing */}
                        <div className="space-y-8 bg-white/[0.02] p-8 rounded-3xl border border-white/5">
                            <div className="flex items-center justify-between">
                                <h3 className="text-[10px] font-bold text-gray-500 uppercase tracking-widest flex items-center gap-2">
                                    <Users size={14} /> Staffing (Gap Filling)
                                </h3>
                                <div className={`px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider ${totalExtras === 0 ? 'bg-green-500/10 text-green-400' : 'bg-orange-500/10 text-orange-400'}`}>
                                    {totalExtras === 0 ? 'Staffing Complet' : `${totalExtras} Extras Nécessaires`}
                                </div>
                            </div>

                            <div className="space-y-8">
                                {staffingRequirements.map((req, idx) => {
                                    const extrasNeeded = Math.max(0, req.needed - req.assignedEmployeeIds.length);

                                    return (
                                        <div key={idx} className="space-y-4">
                                            <div className="flex items-center justify-between">
                                                <span className="font-bold text-white">{req.staffTypeName}</span>
                                                <div className="flex items-center gap-3">
                                                    <span className="text-xs text-gray-500">Besoin:</span>
                                                    <input 
                                                        type="number"
                                                        min="0"
                                                        value={req.needed}
                                                        onChange={e => updateStaffingNeed(req.staffTypeId, parseInt(e.target.value) || 0)}
                                                        className="w-16 bg-black border border-white/10 rounded-lg px-2 py-1 text-center text-white font-bold"
                                                    />
                                                </div>
                                            </div>

                                            {/* Internal Booking */}
                                            <div className="space-y-2">
                                                <p className="text-[10px] font-bold text-gray-600 uppercase tracking-widest">Booking Interne</p>
                                                <div className="flex flex-wrap gap-2">
                                                    {employees
                                                        .filter(emp => emp.tags?.includes(req.staffTypeName))
                                                        .map(emp => {
                                                            const isAssigned = req.assignedEmployeeIds.includes(emp.id);
                                                            return (
                                                                <button
                                                                    key={emp.id}
                                                                    type="button"
                                                                    onClick={() => toggleAssignment(emp.id, req.staffTypeId)}
                                                                    className={`px-3 py-1.5 rounded-lg text-xs font-medium border transition-all ${
                                                                        isAssigned 
                                                                            ? 'bg-blue-500/20 border-blue-500/50 text-blue-400' 
                                                                            : 'bg-black border-white/5 text-gray-500 hover:border-white/20'
                                                                    }`}
                                                                >
                                                                    {emp.name}
                                                                </button>
                                                            );
                                                        })}
                                                </div>
                                            </div>

                                            {/* Extras Display */}
                                            <div className="flex items-center justify-between p-3 bg-black/40 rounded-xl border border-white/5">
                                                <span className="text-xs font-bold text-gray-500 uppercase tracking-widest">Extras à prévoir</span>
                                                <span className={`text-lg font-bold ${extrasNeeded > 0 ? 'text-orange-400' : 'text-green-400'}`}>
                                                    {extrasNeeded}
                                                </span>
                                            </div>
                                        </div>
                                    );
                                })}
                            </div>
                        </div>
                    </div>

                    <div className="pt-10 border-t border-white/5 flex gap-4">
                        <button 
                            type="button"
                            onClick={onClose}
                            className="flex-1 px-8 py-4 rounded-2xl font-bold border border-white/10 text-white hover:bg-white/5 transition-all"
                        >
                            Annuler
                        </button>
                        <button 
                            type="submit"
                            disabled={loading}
                            className="flex-[2] bg-white text-black px-8 py-4 rounded-2xl font-bold hover:bg-gray-200 transition-all shadow-xl shadow-white/10 disabled:opacity-50 flex items-center justify-center gap-2"
                        >
                            {loading ? 'Création...' : (
                                <>
                                    <CheckCircle2 size={20} />
                                    <span>Confirmer la Privatisation</span>
                                </>
                            )}
                        </button>
                    </div>
                </form>
            </motion.div>
        </div>
    );
};
