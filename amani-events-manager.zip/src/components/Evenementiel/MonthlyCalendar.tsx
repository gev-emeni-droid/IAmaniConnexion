import React, { useMemo } from 'react';
import { 
    format, 
    startOfMonth, 
    endOfMonth, 
    startOfWeek, 
    endOfWeek, 
    eachDayOfInterval, 
    isSameMonth, 
    isSameDay, 
    addMonths, 
    subMonths,
    parseISO,
    isWithinInterval
} from 'date-fns';
import { fr } from 'date-fns/locale';
import { ChevronLeft, ChevronRight, Clock, Users } from 'lucide-react';
import { motion } from 'motion/react';

interface Event {
    id: string;
    type: 'PRIVÉ' | 'PROFESSIONNEL';
    first_name?: string;
    last_name?: string;
    company_name?: string;
    organizer_name?: string;
    start_time: string;
    end_time: string;
    num_people: number;
    spaces: any[];
    staff: any[];
}

interface Props {
    month: number;
    year: number;
    events: Event[];
    onMonthChange: (month: number, year: number) => void;
    onEventClick: (event: Event) => void;
}

export const MonthlyCalendar = ({ month, year, events, onMonthChange, onEventClick }: Props) => {
    const currentMonth = useMemo(() => new Date(year, month - 1), [month, year]);
    
    const days = useMemo(() => {
        const start = startOfWeek(startOfMonth(currentMonth), { weekStartsOn: 1 });
        const end = endOfWeek(endOfMonth(currentMonth), { weekStartsOn: 1 });
        return eachDayOfInterval({ start, end });
    }, [currentMonth]);

    const handlePrevMonth = () => {
        const prev = subMonths(currentMonth, 1);
        onMonthChange(prev.getMonth() + 1, prev.getFullYear());
    };

    const handleNextMonth = () => {
        const next = addMonths(currentMonth, 1);
        onMonthChange(next.getMonth() + 1, next.getFullYear());
    };

    // Group events by day
    const eventsByDay = useMemo(() => {
        const map: Record<string, Event[]> = {};
        events.forEach(event => {
            const start = parseISO(event.start_time);
            const key = format(start, 'yyyy-MM-dd');
            if (!map[key]) map[key] = [];
            map[key].push(event);
        });
        return map;
    }, [events]);

    return (
        <div className="bg-[#0A0A0A] rounded-3xl border border-white/5 overflow-hidden shadow-2xl">
            {/* Header */}
            <div className="p-8 flex items-center justify-between border-b border-white/5 bg-[#111111]">
                <h2 className="text-2xl font-bold text-white capitalize">
                    {format(currentMonth, 'MMMM yyyy', { locale: fr })}
                </h2>
                <div className="flex gap-2">
                    <button 
                        onClick={handlePrevMonth}
                        className="p-2 hover:bg-white/5 rounded-lg text-gray-400 transition-all"
                    >
                        <ChevronLeft size={24} />
                    </button>
                    <button 
                        onClick={handleNextMonth}
                        className="p-2 hover:bg-white/5 rounded-lg text-gray-400 transition-all"
                    >
                        <ChevronRight size={24} />
                    </button>
                </div>
            </div>

            {/* Grid Header */}
            <div className="grid grid-cols-7 border-b border-white/5 bg-[#0D0D0D]">
                {['Lun', 'Mar', 'Mer', 'Jeu', 'Ven', 'Sam', 'Dim'].map(day => (
                    <div key={day} className="py-4 text-center text-[10px] font-bold text-gray-500 uppercase tracking-widest">
                        {day}
                    </div>
                ))}
            </div>

            {/* Grid Body */}
            <div className="grid grid-cols-7 auto-rows-[160px]">
                {days.map((day, i) => {
                    const dayKey = format(day, 'yyyy-MM-dd');
                    const dayEvents = eventsByDay[dayKey] || [];
                    const isCurrentMonth = isSameMonth(day, currentMonth);

                    return (
                        <div 
                            key={i} 
                            className={`border-r border-b border-white/5 p-2 relative group transition-all ${
                                !isCurrentMonth ? 'bg-black/40 opacity-30' : 'bg-transparent hover:bg-white/[0.02]'
                            }`}
                        >
                            <span className={`text-xs font-bold ${isCurrentMonth ? 'text-gray-400' : 'text-gray-700'}`}>
                                {format(day, 'd')}
                            </span>

                            <div className="mt-2 space-y-1 overflow-y-auto max-h-[120px] scrollbar-hide">
                                {dayEvents.map(event => {
                                    const spaceColor = event.spaces?.[0]?.color || '#3b82f6';
                                    const title = event.type === 'PRIVÉ' 
                                        ? `${event.first_name} ${event.last_name}` 
                                        : event.company_name;

                                    return (
                                        <motion.button
                                            key={event.id}
                                            whileHover={{ scale: 1.02 }}
                                            onClick={() => onEventClick(event)}
                                            className="w-full text-left p-2 rounded-lg text-[9px] font-bold relative overflow-hidden group/event border border-white/5"
                                            style={{ 
                                                backgroundColor: `${spaceColor}15`, 
                                                color: spaceColor 
                                            }}
                                        >
                                            <div className="absolute top-0 left-0 w-1 h-full" style={{ backgroundColor: spaceColor }} />
                                            <div className="truncate font-black uppercase mb-1">{title}</div>
                                            <div className="flex items-center justify-between opacity-80">
                                                <div className="flex items-center gap-1">
                                                    <Users size={8} />
                                                    <span>{event.num_people}</span>
                                                </div>
                                                <div className="flex items-center gap-1">
                                                    <Clock size={8} />
                                                    <span>{format(parseISO(event.start_time), 'HH:mm')} - {format(parseISO(event.end_time), 'HH:mm')}</span>
                                                </div>
                                            </div>
                                        </motion.button>
                                    );
                                })}
                            </div>
                        </div>
                    );
                })}
            </div>
        </div>
    );
};
