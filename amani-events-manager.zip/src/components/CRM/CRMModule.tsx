import React, { useState, useEffect } from 'react';
import { moduleApi } from '../../lib/api';
import { 
    Users, 
    Search, 
    Phone, 
    Mail, 
    Building2, 
    History, 
    Calendar,
    ChevronRight,
    User,
    ArrowLeft
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export const CRMModule = () => {
    const [contacts, setContacts] = useState<any[]>([]);
    const [selectedContact, setSelectedContact] = useState<any | null>(null);
    const [loading, setLoading] = useState(true);
    const [search, setSearch] = useState('');

    useEffect(() => {
        loadContacts();
    }, []);

    const loadContacts = async () => {
        setLoading(true);
        try {
            const data = await moduleApi.getCRMContacts();
            setContacts(data);
        } catch (e) {
            console.error(e);
        } finally {
            setLoading(false);
        }
    };

    const loadContactDetail = async (id: string) => {
        try {
            const data = await moduleApi.getCRMContact(id);
            setSelectedContact(data);
        } catch (e) {
            console.error(e);
        }
    };

    const filteredContacts = contacts.filter(c => 
        `${c.first_name} ${c.last_name} ${c.company_name} ${c.phone}`.toLowerCase().includes(search.toLowerCase())
    );

    if (selectedContact) {
        return (
            <div className="space-y-10">
                <header className="flex items-center gap-4">
                    <button 
                        onClick={() => setSelectedContact(null)}
                        className="p-2 hover:bg-white/5 rounded-lg text-gray-400"
                    >
                        <ArrowLeft size={24} />
                    </button>
                    <div>
                        <h1 className="text-3xl font-bold text-white tracking-tight">Fiche Contact</h1>
                        <p className="text-gray-500">Détails et historique des privatisations</p>
                    </div>
                </header>

                <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
                    {/* Profil Card */}
                    <div className="lg:col-span-1 space-y-6">
                        <div className="bg-[#111111] rounded-3xl border border-white/5 p-8 text-center">
                            <div className="w-24 h-24 bg-white/5 rounded-full flex items-center justify-center mx-auto mb-6 border border-white/10">
                                <User size={48} className="text-white" />
                            </div>
                            <h2 className="text-2xl font-bold text-white">
                                {selectedContact.type === 'PRIVÉ' ? `${selectedContact.first_name} ${selectedContact.last_name}` : selectedContact.company_name}
                            </h2>
                            <p className="text-blue-400 text-xs font-bold uppercase tracking-widest mt-2">{selectedContact.type}</p>
                            
                            <div className="mt-10 space-y-4 text-left">
                                <div className="flex items-center gap-4 p-4 bg-black rounded-2xl border border-white/5">
                                    <Phone size={18} className="text-gray-500" />
                                    <span className="text-white font-medium">{selectedContact.phone}</span>
                                </div>
                                <div className="flex items-center gap-4 p-4 bg-black rounded-2xl border border-white/5">
                                    <Mail size={18} className="text-gray-500" />
                                    <span className="text-white font-medium">{selectedContact.email || 'Non renseigné'}</span>
                                </div>
                                {selectedContact.type === 'PROFESSIONNEL' && (
                                    <div className="flex items-center gap-4 p-4 bg-black rounded-2xl border border-white/5">
                                        <Building2 size={18} className="text-gray-500" />
                                        <span className="text-white font-medium">{selectedContact.organizer_name}</span>
                                    </div>
                                )}
                            </div>
                        </div>
                    </div>

                    {/* Historique */}
                    <div className="lg:col-span-2 space-y-6">
                        <div className="flex items-center gap-3 mb-4">
                            <History className="text-white" size={24} />
                            <h3 className="text-xl font-bold text-white">Historique des Événements</h3>
                        </div>

                        <div className="space-y-4">
                            {selectedContact.history?.map((event: any) => (
                                <div key={event.id} className="bg-[#111111] rounded-2xl border border-white/5 p-6 flex items-center justify-between group hover:border-white/20 transition-all">
                                    <div className="flex items-center gap-6">
                                        <div className="w-12 h-12 bg-white/5 rounded-xl flex flex-col items-center justify-center text-white border border-white/10">
                                            <span className="text-[10px] font-bold uppercase opacity-50">{new Date(event.start_time).toLocaleDateString('fr-FR', { month: 'short' })}</span>
                                            <span className="text-lg font-bold leading-none">{new Date(event.start_time).getDate()}</span>
                                        </div>
                                        <div>
                                            <p className="text-white font-bold">{event.type === 'PRIVÉ' ? 'Privatisation Particulier' : `Event Pro - ${event.company_name}`}</p>
                                            <div className="flex items-center gap-4 mt-1">
                                                <span className="text-xs text-gray-500 flex items-center gap-1">
                                                    <Calendar size={12} />
                                                    {event.spaces || 'N/A'}
                                                </span>
                                                <span className="text-xs text-gray-500 flex items-center gap-1">
                                                    <Users size={12} />
                                                    {event.num_people} pers.
                                                </span>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="text-right">
                                        <p className="text-xs text-gray-500">{new Date(event.start_time).getFullYear()}</p>
                                        <p className="text-xs font-bold text-white mt-1">{new Date(event.start_time).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</p>
                                    </div>
                                </div>
                            ))}
                            {(!selectedContact.history || selectedContact.history.length === 0) && (
                                <p className="text-center text-gray-600 py-10 bg-[#111111] rounded-2xl border border-dashed border-white/10">Aucun historique trouvé</p>
                            )}
                        </div>
                    </div>
                </div>
            </div>
        );
    }

    return (
        <div className="space-y-10">
            <header className="flex items-center justify-between">
                <div>
                    <h1 className="text-3xl font-bold text-white tracking-tight">CRM Contacts</h1>
                    <p className="text-gray-500 mt-1">Base de données clients et historique événementiel</p>
                </div>
                <div className="relative w-80">
                    <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500" size={20} />
                    <input 
                        type="text"
                        placeholder="Rechercher un contact..."
                        value={search}
                        onChange={e => setSearch(e.target.value)}
                        className="w-full bg-[#111111] border border-white/10 rounded-xl pl-12 pr-4 py-3 text-white outline-none focus:border-white transition-all"
                    />
                </div>
            </header>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredContacts.map((contact, i) => (
                    <motion.button
                        key={contact.id}
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: i * 0.05 }}
                        onClick={() => loadContactDetail(contact.id)}
                        className="bg-[#111111] p-6 rounded-2xl border border-white/5 hover:border-white/20 transition-all text-left group"
                    >
                        <div className="flex items-center gap-4 mb-6">
                            <div className="w-12 h-12 bg-white/5 rounded-full flex items-center justify-center border border-white/10 group-hover:bg-white group-hover:text-black transition-all">
                                <User size={24} />
                            </div>
                            <div className="flex-1 min-w-0">
                                <h3 className="text-lg font-bold text-white truncate">
                                    {contact.type === 'PRIVÉ' ? `${contact.first_name} ${contact.last_name}` : contact.company_name}
                                </h3>
                                <p className="text-xs text-gray-500 uppercase tracking-widest font-bold">{contact.type}</p>
                            </div>
                            <ChevronRight className="text-gray-700 group-hover:text-white transition-all" size={20} />
                        </div>

                        <div className="space-y-3">
                            <div className="flex items-center gap-3 text-sm text-gray-400">
                                <Phone size={14} className="text-gray-600" />
                                <span>{contact.phone}</span>
                            </div>
                            <div className="flex items-center gap-3 text-sm text-gray-400">
                                <Mail size={14} className="text-gray-600" />
                                <span className="truncate">{contact.email || 'N/A'}</span>
                            </div>
                        </div>

                        <div className="mt-6 pt-6 border-t border-white/5 flex items-center justify-between">
                            <span className="text-[10px] text-gray-600 font-bold uppercase tracking-widest">Dernière activité</span>
                            <span className="text-[10px] text-gray-400 font-bold">{new Date(contact.updated_at).toLocaleDateString()}</span>
                        </div>
                    </motion.button>
                ))}

                {filteredContacts.length === 0 && !loading && (
                    <div className="col-span-full py-20 text-center bg-[#111111] rounded-3xl border border-dashed border-white/10">
                        <Users size={48} className="text-gray-700 mx-auto mb-4" />
                        <p className="text-gray-500 font-medium">Aucun contact trouvé</p>
                    </div>
                )}
            </div>
        </div>
    );
};
