import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate, Link, useNavigate, useParams } from 'react-router-dom';
import { AuthProvider, useAuth } from './context/AuthContext';
import { 
    LayoutDashboard, 
    Users, 
    Calendar, 
    Briefcase, 
    FileText, 
    Settings, 
    LogOut, 
    Plus, 
    CheckCircle, 
    XCircle,
    ChevronRight,
    ShieldCheck,
    Lock,
    Mail,
    Trash2,
    ToggleLeft,
    ToggleRight,
    Search,
    Filter,
    Download,
    MapPin,
    UserCheck,
    Palette
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { authApi, adminApi, moduleApi } from './lib/api';
import { EvenementielModule } from './components/Evenementiel/EvenementielModule';
import { CRMModule } from './components/CRM/CRMModule';
import { AdminEvenementielConfig } from './components/Admin/AdminEvenementielConfig';

// --- Components ---

const SidebarItem = ({ icon: Icon, label, to, active }: any) => (
    <Link 
        to={to} 
        className={`flex items-center gap-3 px-4 py-3 rounded-lg transition-all ${
            active ? 'bg-white text-black' : 'text-gray-400 hover:bg-white/5 hover:text-white'
        }`}
    >
        <Icon size={20} />
        <span className="font-medium">{label}</span>
    </Link>
);

const Layout = ({ children }: { children: React.ReactNode }) => {
    const { user, logout } = useAuth();
    const navigate = useNavigate();
    const [activeModules, setActiveModules] = React.useState<string[]>([]);

    React.useEffect(() => {
        if (user && user.type !== 'admin') {
            loadModules();
            checkStatus();
        }
    }, [user]);

    const checkStatus = async () => {
        try {
            const me = await authApi.getMe();
            if (me.status === 'blocked') {
                logout();
                navigate('/login');
            }
        } catch (e) {
            // If 401/403, logout
            logout();
            navigate('/login');
        }
    };

    const loadModules = async () => {
        try {
            // For clients/collaborators, we fetch their active modules via the /me/modules endpoint
            const modules = await authApi.getMyModules();
            setActiveModules(modules.filter((m: any) => m.is_active === 1).map((m: any) => m.module_name));
        } catch (e) {
            console.error('Failed to load active modules', e);
        }
    };

    const handleLogout = () => {
        logout();
        navigate('/login');
    };

    const isModuleActive = (name: string) => {
        if (user?.type === 'admin') return false; // Admin doesn't use modules
        return activeModules.includes(name);
    };

    return (
        <div className="flex min-h-screen bg-[#0A0A0A] text-[#EDEDED]">
            {/* Sidebar */}
            <aside className="w-64 bg-[#111111] border-r border-white/5 p-6 flex flex-col fixed h-full">
                <div className="flex items-center gap-2 mb-10 px-2">
                    <div className="w-8 h-8 bg-white rounded-lg flex items-center justify-center">
                        <ShieldCheck className="text-black" size={20} />
                    </div>
                    <span className="font-bold text-xl tracking-tight text-white">AMANI</span>
                </div>

                <nav className="flex-1 space-y-1 overflow-y-auto">
                    <SidebarItem icon={LayoutDashboard} label="Dashboard" to="/" active={window.location.pathname === '/'} />
                    
                    {user?.type === 'admin' ? (
                        <>
                            <div className="mt-8 mb-2 px-4 text-[10px] font-bold text-gray-500 uppercase tracking-widest">Administration</div>
                            <SidebarItem icon={Users} label="Gestion Clients" to="/admin/clients" active={window.location.pathname.startsWith('/admin/clients')} />
                        </>
                    ) : (
                        <>
                            <div className="mt-8 mb-2 px-4 text-[10px] font-bold text-gray-500 uppercase tracking-widest">Mes Modules</div>
                            {isModuleActive('planning') && <SidebarItem icon={Calendar} label="Planning" to="/planning" active={window.location.pathname === '/planning'} />}
                            {isModuleActive('evenementiel') && (
                                <>
                                    <SidebarItem icon={Briefcase} label="Événementiel" to="/evenementiel" active={window.location.pathname === '/evenementiel'} />
                                    <SidebarItem icon={Users} label="CRM Contacts" to="/crm" active={window.location.pathname === '/crm'} />
                                </>
                            )}
                            {isModuleActive('facture') && <SidebarItem icon={FileText} label="Factures" to="/factures" active={window.location.pathname === '/factures'} />}
                            {isModuleActive('employes') && <SidebarItem icon={Users} label="Employés" to="/employes" active={window.location.pathname === '/employes'} />}
                        </>
                    )}
                </nav>

                <div className="mt-auto pt-6 border-t border-white/5">
                    <div className="flex items-center gap-3 px-2 mb-6">
                        <div className="w-10 h-10 bg-white/5 rounded-full flex items-center justify-center font-bold text-white border border-white/10">
                            {user?.name ? user.name[0].toUpperCase() : '?'}
                        </div>
                        <div className="flex-1 min-w-0">
                            <p className="text-sm font-bold truncate text-white">{user?.name}</p>
                            <p className="text-xs text-gray-500 truncate capitalize">{user?.type}</p>
                        </div>
                    </div>
                    <button 
                        onClick={handleLogout}
                        className="w-full flex items-center gap-3 px-4 py-3 text-red-400 hover:bg-red-500/10 rounded-lg transition-all font-medium"
                    >
                        <LogOut size={20} />
                        <span>Déconnexion</span>
                    </button>
                </div>
            </aside>

            {/* Main Content */}
            <main className="flex-1 ml-64 p-10 overflow-auto">
                <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.3 }}
                >
                    {children}
                </motion.div>
            </main>
        </div>
    );
};

// --- Views ---

const LoginView = () => {
    const [email, setEmail] = React.useState('');
    const [password, setPassword] = React.useState('');
    const [error, setError] = React.useState('');
    const { login } = useAuth();
    const navigate = useNavigate();

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setError('');
        try {
            const data = await authApi.login({ email, password });
            login(data.token, data.user);
            navigate('/');
        } catch (err: any) {
            setError(err.message);
        }
    };

    return (
        <div className="min-h-screen bg-[#0A0A0A] flex items-center justify-center p-6">
            <motion.div 
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                className="w-full max-w-md bg-[#111111] rounded-2xl shadow-2xl p-10 border border-white/5"
            >
                <div className="flex flex-col items-center mb-10">
                    <div className="w-12 h-12 bg-white rounded-xl flex items-center justify-center mb-4">
                        <ShieldCheck className="text-black" size={28} />
                    </div>
                    <h1 className="text-2xl font-bold tracking-tight text-white">Connexion Amani</h1>
                    <p className="text-gray-500 text-sm mt-2">Entrez vos identifiants pour accéder à la plateforme</p>
                </div>

                <form onSubmit={handleSubmit} className="space-y-6">
                    {error && (
                        <div className="p-4 bg-red-500/10 text-red-400 text-sm rounded-lg flex items-center gap-2 border border-red-500/20">
                            <XCircle size={16} />
                            {error}
                        </div>
                    )}
                    <div className="space-y-2">
                        <label className="text-xs font-bold text-gray-500 uppercase tracking-widest">Email</label>
                        <input 
                            type="email" 
                            value={email}
                            onChange={(e) => setEmail(e.target.value)}
                            className="w-full px-4 py-3 rounded-lg bg-black border border-white/10 text-white focus:border-white focus:ring-0 transition-all outline-none"
                            placeholder="nom@exemple.com"
                            required
                        />
                    </div>
                    <div className="space-y-2">
                        <label className="text-xs font-bold text-gray-500 uppercase tracking-widest">Mot de passe</label>
                        <input 
                            type="password" 
                            value={password}
                            onChange={(e) => setPassword(e.target.value)}
                            className="w-full px-4 py-3 rounded-lg bg-black border border-white/10 text-white focus:border-white focus:ring-0 transition-all outline-none"
                            placeholder="••••••••"
                            required
                        />
                    </div>
                    <button 
                        type="submit"
                        className="w-full bg-white text-black py-4 rounded-lg font-bold hover:bg-gray-200 transition-all shadow-lg shadow-white/5"
                    >
                        Se connecter
                    </button>
                </form>

                <div className="mt-8 pt-8 border-t border-white/5 text-center">
                    <p className="text-xs text-gray-500">
                        Plateforme sécurisée réservée aux clients et collaborateurs autorisés.
                    </p>
                </div>
            </motion.div>
        </div>
    );
};

const DashboardView = () => {
    const { user } = useAuth();
    const [stats, setStats] = React.useState<any[]>([]);
    const [loading, setLoading] = React.useState(true);

    React.useEffect(() => {
        if (user) {
            loadStats();
        }
    }, [user]);

    const loadStats = async () => {
        try {
            if (user?.type === 'admin') {
                const data = await adminApi.getStats();
                setStats([
                    { label: 'Clients Actifs', value: data.clientsCount.toString(), icon: Users, color: 'text-blue-400', bg: 'bg-blue-500/10' },
                    { label: 'Revenus Mensuels', value: data.revenue, icon: FileText, color: 'text-green-400', bg: 'bg-green-500/10' },
                    { label: 'Modules Activés', value: data.activeModulesCount.toString(), icon: Settings, color: 'text-purple-400', bg: 'bg-purple-500/10' },
                    { label: 'Collaborateurs', value: data.collaboratorsCount.toString(), icon: ShieldCheck, color: 'text-orange-400', bg: 'bg-orange-500/10' },
                ]);
            } else {
                // Client stats could be fetched here too
                setStats([
                    { label: 'Employés', value: '12', icon: Users, color: 'text-blue-400', bg: 'bg-blue-500/10' },
                    { label: 'Événements', value: '4', icon: Calendar, color: 'text-purple-400', bg: 'bg-purple-500/10' },
                    { label: 'Factures', value: '28', icon: FileText, color: 'text-orange-400', bg: 'bg-green-500/10' },
                    { label: 'Planning', value: '8', icon: Briefcase, color: 'text-green-400', bg: 'bg-green-500/10' },
                ]);
            }
        } catch (e) {
            console.error(e);
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="space-y-10">
            <header>
                <h1 className="text-3xl font-bold tracking-tight text-white">Tableau de bord</h1>
                <p className="text-gray-500 mt-1">
                    {user?.type === 'admin' 
                        ? 'Vue d\'ensemble de la plateforme Amani.' 
                        : `Bienvenue sur votre espace de gestion, ${user?.name}.`}
                </p>
            </header>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                {stats.map((stat, i) => (
                    <motion.div 
                        key={i} 
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: i * 0.1 }}
                        className="bg-[#111111] p-8 rounded-2xl border border-white/5 shadow-sm"
                    >
                        <div className={`w-12 h-12 ${stat.bg} rounded-xl flex items-center justify-center mb-6`}>
                            <stat.icon className={stat.color} size={24} />
                        </div>
                        <p className="text-gray-500 text-xs font-bold uppercase tracking-widest">{stat.label}</p>
                        <p className="text-3xl font-bold mt-2 text-white">{stat.value}</p>
                    </motion.div>
                ))}
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
                <div className="lg:col-span-2 bg-[#111111] rounded-2xl border border-white/5 p-8">
                    <h2 className="text-lg font-bold mb-8 text-white">Activité récente</h2>
                    <div className="space-y-8">
                        {[1, 2, 3].map((_, i) => (
                            <div key={i} className="flex items-center gap-6 pb-8 border-b border-white/5 last:border-0 last:pb-0">
                                <div className="w-12 h-12 bg-white/5 rounded-full flex items-center justify-center">
                                    <ChevronRight size={18} className="text-gray-600" />
                                </div>
                                <div className="flex-1">
                                    <p className="text-sm font-bold text-white">
                                        {user?.type === 'admin' ? 'Nouveau client créé' : 'Nouvelle facture générée'}
                                    </p>
                                    <p className="text-xs text-gray-500 mt-1">Il y a 2 heures • {user?.type === 'admin' ? 'Client ABC' : 'Facture #882'}</p>
                                </div>
                                <div className="text-sm font-bold text-green-400">
                                    {user?.type === 'admin' ? 'Actif' : '+ 1,200 €'}
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
                
                <div className="bg-white text-black rounded-2xl p-10 shadow-2xl relative overflow-hidden flex flex-col justify-between">
                    <div className="relative z-10">
                        <h2 className="text-xl font-bold mb-4">
                            {user?.type === 'admin' ? 'Maintenance Système' : 'Support Amani'}
                        </h2>
                        <p className="text-gray-600 text-sm leading-relaxed mb-8">
                            {user?.type === 'admin' 
                                ? 'Vérifiez l\'état des serveurs et les logs de sécurité de la plateforme.' 
                                : 'Besoin d\'aide pour configurer vos modules ? Notre équipe est là pour vous.'}
                        </p>
                        <button className="bg-black text-white px-8 py-4 rounded-xl font-bold text-sm hover:bg-gray-900 transition-all shadow-lg shadow-black/10">
                            {user?.type === 'admin' ? 'Voir les logs' : 'Contacter l\'admin'}
                        </button>
                    </div>
                    <div className="absolute -right-10 -bottom-10 w-40 h-40 bg-black/5 rounded-full blur-3xl"></div>
                </div>
            </div>
        </div>
    );
};

const AdminClientsView = () => {
    const { user } = useAuth();
    const [clients, setClients] = React.useState<any[]>([]);
    const [loading, setLoading] = React.useState(true);
    const [showAddModal, setShowAddModal] = React.useState(false);
    const [successData, setSuccessData] = React.useState<any>(null);
    const [newClient, setNewClient] = React.useState({ 
        name: '', 
        email: '',
        modules: [
            { name: 'planning', active: true },
            { name: 'evenementiel', active: false },
            { name: 'facture', active: false },
            { name: 'employes', active: false },
            { name: 'crm', active: false }
        ]
    });

    React.useEffect(() => {
        if (user) {
            loadClients();
        }
    }, [user]);

    const loadClients = async () => {
        try {
            const data = await adminApi.getClients();
            setClients(data);
        } catch (e) {
            console.error(e);
        } finally {
            setLoading(false);
        }
    };

    const handleAddClient = async (e: React.FormEvent) => {
        e.preventDefault();
        try {
            const payload = {
                ...newClient,
                modules: newClient.modules.filter(m => m.active).map(m => m.name)
            };
            const result = await adminApi.createClient(payload);
            setSuccessData({ ...newClient, tempPassword: result.tempPassword });
            setShowAddModal(false);
            setNewClient({ 
                name: '', 
                email: '',
                modules: [
                    { name: 'planning', active: true },
                    { name: 'evenementiel', active: false },
                    { name: 'facture', active: false },
                    { name: 'employes', active: false },
                    { name: 'crm', active: false }
                ]
            });
            loadClients();
        } catch (e: any) {
            console.error(e);
            alert(e.message || 'Erreur lors de la création du client');
        }
    };

    const toggleModule = (name: string) => {
        setNewClient({
            ...newClient,
            modules: newClient.modules.map(m => m.name === name ? { ...m, active: !m.active } : m)
        });
    };

    const handleImpersonate = async (clientId: string) => {
        try {
            const data = await adminApi.impersonateClient(clientId);
            localStorage.setItem('token', data.token);
            window.location.href = '/';
        } catch (e) {
            alert('Erreur lors de la connexion virtuelle');
        }
    };

    return (
        <div className="space-y-10">
            <header className="flex items-center justify-between">
                <div>
                    <h1 className="text-3xl font-bold tracking-tight text-white">Gestion des Clients</h1>
                    <p className="text-gray-500 mt-1">Gérez vos clients, leurs accès et leur statut.</p>
                </div>
                <button 
                    onClick={() => setShowAddModal(true)}
                    className="bg-white text-black px-6 py-3 rounded-lg font-bold flex items-center gap-2 hover:bg-gray-200 transition-all shadow-lg shadow-white/5"
                >
                    <Plus size={20} />
                    <span>Nouveau Client</span>
                </button>
            </header>

            <div className="bg-[#111111] rounded-2xl border border-white/5 shadow-sm overflow-hidden">
                <table className="w-full text-left">
                    <thead>
                        <tr className="bg-black/20 border-b border-white/5">
                            <th className="px-8 py-4 text-xs font-bold text-gray-500 uppercase tracking-widest">Client</th>
                            <th className="px-8 py-4 text-xs font-bold text-gray-500 uppercase tracking-widest">Email</th>
                            <th className="px-8 py-4 text-xs font-bold text-gray-500 uppercase tracking-widest">Statut</th>
                            <th className="px-8 py-4 text-xs font-bold text-gray-500 uppercase tracking-widest">Dernière Connexion</th>
                            <th className="px-8 py-4 text-xs font-bold text-gray-500 uppercase tracking-widest text-right">Actions</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-white/5">
                        {loading ? (
                            <tr><td colSpan={5} className="px-8 py-10 text-center text-gray-500">Chargement...</td></tr>
                        ) : clients.length === 0 ? (
                            <tr><td colSpan={5} className="px-8 py-10 text-center text-gray-500">Aucun client trouvé.</td></tr>
                        ) : clients.map((client) => (
                            <tr key={client.id} className="hover:bg-white/5 transition-all">
                                <td className="px-8 py-6">
                                    <div className="font-bold text-white">{client.name}</div>
                                    <div className="text-[10px] text-gray-600 font-mono mt-0.5 uppercase">ID: {client.id}</div>
                                </td>
                                <td className="px-8 py-6 text-gray-400">{client.email}</td>
                                <td className="px-8 py-6">
                                    <span className={`px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                                        client.status === 'active' ? 'bg-green-500/10 text-green-400' : 'bg-red-500/10 text-red-400'
                                    }`}>
                                        {client.status === 'active' ? 'Actif' : 'Bloqué'}
                                    </span>
                                </td>
                                <td className="px-8 py-6 text-gray-500 text-sm">
                                    {client.last_login ? new Date(client.last_login).toLocaleString() : 'Jamais'}
                                </td>
                                <td className="px-8 py-6 text-right">
                                    <div className="flex items-center justify-end gap-3">
                                        <button 
                                            onClick={() => handleImpersonate(client.id)}
                                            className="p-2 text-gray-400 hover:text-blue-400 transition-all"
                                            title="Entrer dans le compte"
                                        >
                                            <LayoutDashboard size={18} />
                                        </button>
                                        <Link 
                                            to={`/admin/clients/${client.id}`}
                                            className="inline-flex items-center gap-2 text-sm font-bold text-white hover:text-gray-300 transition-all bg-white/5 px-4 py-2 rounded-lg"
                                        >
                                            Gérer <ChevronRight size={16} />
                                        </Link>
                                    </div>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>

            {/* Modal Nouveau Client */}
            <AnimatePresence>
                {showAddModal && (
                    <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-6 overflow-y-auto">
                        <motion.div 
                            initial={{ opacity: 0, scale: 0.95 }}
                            animate={{ opacity: 1, scale: 1 }}
                            exit={{ opacity: 0, scale: 0.95 }}
                            className="w-full max-w-2xl bg-[#111111] rounded-2xl p-10 shadow-2xl border border-white/5 my-auto"
                        >
                            <h2 className="text-2xl font-bold mb-8 text-white">Nouveau Client</h2>
                            <form onSubmit={handleAddClient} className="space-y-8">
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                    <div className="space-y-2">
                                        <label className="text-xs font-bold text-gray-500 uppercase tracking-widest">Nom de l'entreprise</label>
                                        <input 
                                            type="text" required
                                            value={newClient.name}
                                            onChange={(e) => setNewClient({ ...newClient, name: e.target.value })}
                                            className="w-full px-4 py-3 rounded-lg bg-black border border-white/10 text-white focus:border-white outline-none transition-all"
                                            placeholder="ex: Acme Corp"
                                        />
                                    </div>
                                    <div className="space-y-2">
                                        <label className="text-xs font-bold text-gray-500 uppercase tracking-widest">Email de contact</label>
                                        <input 
                                            type="email" required
                                            value={newClient.email}
                                            onChange={(e) => setNewClient({ ...newClient, email: e.target.value })}
                                            className="w-full px-4 py-3 rounded-lg bg-black border border-white/10 text-white focus:border-white outline-none transition-all"
                                            placeholder="contact@acme.com"
                                        />
                                    </div>
                                </div>

                                <div className="space-y-4">
                                    <label className="text-xs font-bold text-gray-500 uppercase tracking-widest">Modules à activer</label>
                                    <div className="grid grid-cols-2 gap-4">
                                        {newClient.modules.map((m) => (
                                            <button
                                                key={m.name}
                                                type="button"
                                                onClick={() => toggleModule(m.name)}
                                                className={`flex items-center justify-between p-4 rounded-xl border transition-all ${
                                                    m.active 
                                                        ? 'bg-white/5 border-white/20 text-white' 
                                                        : 'bg-black border-white/5 text-gray-600'
                                                }`}
                                            >
                                                <span className="capitalize font-medium">{m.name}</span>
                                                {m.active ? <ToggleRight size={24} className="text-white" /> : <ToggleLeft size={24} />}
                                            </button>
                                        ))}
                                    </div>
                                </div>

                                <div className="flex gap-4 pt-4">
                                    <button 
                                        type="button"
                                        onClick={() => setShowAddModal(false)}
                                        className="flex-1 px-6 py-4 rounded-lg font-bold border border-white/10 text-white hover:bg-white/5 transition-all"
                                    >
                                        Annuler
                                    </button>
                                    <button 
                                        type="submit"
                                        className="flex-1 bg-white text-black px-6 py-4 rounded-lg font-bold hover:bg-gray-200 transition-all shadow-lg shadow-white/5"
                                    >
                                        Créer le Client
                                    </button>
                                </div>
                            </form>
                        </motion.div>
                    </div>
                )}
            </AnimatePresence>

            {/* Modal Succès Création */}
            <AnimatePresence>
                {successData && (
                    <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-6">
                        <motion.div 
                            initial={{ opacity: 0, scale: 0.95 }}
                            animate={{ opacity: 1, scale: 1 }}
                            className="w-full max-w-md bg-[#111111] rounded-2xl p-10 shadow-2xl border border-white/5 text-center"
                        >
                            <div className="w-16 h-16 bg-green-500/10 rounded-full flex items-center justify-center mx-auto mb-6">
                                <ShieldCheck className="text-green-400" size={32} />
                            </div>
                            <h2 className="text-2xl font-bold text-white mb-2">Client Créé !</h2>
                            <p className="text-gray-500 mb-8">Le compte de {successData.name} a été créé. Si l'email ne parvient pas, voici les identifiants :</p>
                            
                            <div className="bg-black rounded-xl p-6 mb-8 text-left space-y-4 border border-white/5">
                                <div>
                                    <label className="text-[10px] font-bold text-gray-600 uppercase tracking-widest block mb-1">Email</label>
                                    <div className="text-white font-mono">{successData.email}</div>
                                </div>
                                <div>
                                    <label className="text-[10px] font-bold text-gray-600 uppercase tracking-widest block mb-1">Mot de passe temporaire</label>
                                    <div className="text-white font-mono text-lg tracking-wider">{successData.tempPassword}</div>
                                </div>
                            </div>
                            
                            <button 
                                onClick={() => setSuccessData(null)}
                                className="w-full bg-white text-black py-4 rounded-lg font-bold hover:bg-gray-200 transition-all"
                            >
                                J'ai noté les identifiants
                            </button>
                        </motion.div>
                    </div>
                )}
            </AnimatePresence>
        </div>
    );
};

const AdminClientDetailView = () => {
    const { id } = useParams();
    const navigate = useNavigate();
    const [client, setClient] = React.useState<any>(null);
    const [modules, setModules] = React.useState<any[]>([]);
    const [collaborators, setCollaborators] = React.useState<any[]>([]);
    const [spaces, setSpaces] = React.useState<any[]>([]);
    const [loading, setLoading] = React.useState(true);
    const [showCollabModal, setShowCollabModal] = React.useState(false);
    const [showSpaceModal, setShowSpaceModal] = React.useState(false);
    const [newCollab, setNewCollab] = React.useState({ name: '', email: '', role: '' });
    const [newSpace, setNewSpace] = React.useState({ name: '', color: '#ffffff' });
    const [editMode, setEditMode] = React.useState(false);
    const [showEvenementielConfig, setShowEvenementielConfig] = React.useState(false);
    const [editData, setEditData] = React.useState({ name: '', email: '' });

    React.useEffect(() => {
        if (id) loadData();
    }, [id]);

    const loadData = async () => {
        try {
            const [clients, m, c, s] = await Promise.all([
                adminApi.getClients(),
                adminApi.getClientModules(id!),
                adminApi.getCollaborators(id!),
                adminApi.getSpaces(id!)
            ]);
            const currentClient = clients.find((cl: any) => cl.id === id);
            setClient(currentClient);
            setEditData({ name: currentClient.name, email: currentClient.email });
            setModules(m);
            setCollaborators(c);
            setSpaces(s);
        } catch (e) {
            console.error(e);
        } finally {
            setLoading(false);
        }
    };

    const handleUpdateModules = async (moduleName: string, active: boolean) => {
        try {
            const updatedModules = modules.map(m => 
                m.module_name === moduleName ? { ...m, is_active: active ? 1 : 0 } : m
            );
            await adminApi.updateClientModules(id!, updatedModules.map(m => ({
                name: m.module_name,
                active: m.is_active === 1
            })));
            setModules(updatedModules);
        } catch (e) {
            alert('Erreur lors de la mise à jour des modules');
        }
    };

    const handleUpdateStatus = async (status: string) => {
        try {
            await adminApi.updateClient(id!, { status });
            setClient({ ...client, status });
        } catch (e) {
            alert('Erreur lors de la mise à jour du statut');
        }
    };

    const handleUpdateProfile = async (e: React.FormEvent) => {
        e.preventDefault();
        try {
            await adminApi.updateClient(id!, editData);
            setClient({ ...client, ...editData });
            setEditMode(false);
        } catch (e) {
            alert('Erreur lors de la mise à jour du profil');
        }
    };

    const handleDeleteClient = async () => {
        if (!confirm('Êtes-vous sûr de vouloir supprimer ce client ? Cette action est irréversible et supprimera TOUTES les données associées.')) return;
        try {
            await adminApi.deleteClient(id!);
            navigate('/admin/clients');
        } catch (e) {
            alert('Erreur lors de la suppression');
        }
    };

    const handleResetPassword = async () => {
        if (!confirm('Renvoyer un nouveau mot de passe temporaire au client ?')) return;
        try {
            await adminApi.resetClientPassword(id!);
            alert('Un nouveau mot de passe a été envoyé par email.');
        } catch (e) {
            alert('Erreur lors de la réinitialisation');
        }
    };

    const handleForceReset = async () => {
        if (!confirm('Générer un lien de réinitialisation et l\'envoyer au client ?')) return;
        try {
            await adminApi.forceResetClientPassword(id!);
            alert('Un lien de réinitialisation a été envoyé par email.');
        } catch (e) {
            alert('Erreur lors de l\'envoi du lien');
        }
    };

    const handleAddCollab = async (e: React.FormEvent) => {
        e.preventDefault();
        try {
            await adminApi.createCollaborator(id!, newCollab);
            setShowCollabModal(false);
            setNewCollab({ name: '', email: '', role: '' });
            loadData();
        } catch (e) {
            alert('Erreur lors de la création du collaborateur');
        }
    };

    const handleAddSpace = async (e: React.FormEvent) => {
        e.preventDefault();
        try {
            await adminApi.createSpace(id!, newSpace);
            setShowSpaceModal(false);
            setNewSpace({ name: '', color: '#ffffff' });
            loadData();
        } catch (e) {
            alert('Erreur lors de la création de l\'espace');
        }
    };

    const handleDeleteSpace = async (spaceId: string) => {
        if (!confirm('Supprimer cet espace ?')) return;
        try {
            await adminApi.deleteSpace(id!, spaceId);
            loadData();
        } catch (e) {
            alert('Erreur lors de la suppression');
        }
    };

    if (loading) return <div className="text-center py-20 text-gray-500">Chargement...</div>;
    if (!client) return <div className="text-center py-20 text-gray-500">Client introuvable</div>;

    if (showEvenementielConfig) {
        return <AdminEvenementielConfig clientId={id!} clientName={client.name} onBack={() => setShowEvenementielConfig(false)} />;
    }

    return (
        <div className="space-y-10">
            <header className="flex flex-col md:flex-row md:items-center justify-between gap-6">
                <div>
                    <Link to="/admin/clients" className="text-sm text-gray-500 hover:text-white flex items-center gap-1 mb-2 transition-all">
                        <ChevronRight size={14} className="rotate-180" /> Retour aux clients
                    </Link>
                    <div className="flex items-center gap-4">
                        <h1 className="text-3xl font-bold tracking-tight text-white">{client.name}</h1>
                        <span className={`px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                            client.status === 'active' ? 'bg-green-500/10 text-green-400' : 'bg-red-500/10 text-red-400'
                        }`}>
                            {client.status === 'active' ? 'Actif' : 'Bloqué'}
                        </span>
                    </div>
                    <p className="text-gray-500 mt-1">ID: {client.id} • Email: {client.email}</p>
                </div>
                <div className="flex flex-wrap gap-3">
                    <button 
                        onClick={() => handleUpdateStatus(client.status === 'active' ? 'blocked' : 'active')}
                        className={`px-4 py-2 rounded-lg font-bold text-sm transition-all flex items-center gap-2 ${
                            client.status === 'active' 
                                ? 'bg-red-500/10 text-red-400 hover:bg-red-500/20' 
                                : 'bg-green-500/10 text-green-400 hover:bg-green-500/20'
                        }`}
                    >
                        {client.status === 'active' ? <Lock size={16} /> : <ShieldCheck size={16} />}
                        {client.status === 'active' ? 'Bloquer le compte' : 'Débloquer le compte'}
                    </button>
                    <button 
                        onClick={handleResetPassword}
                        className="bg-white/5 border border-white/10 text-white px-4 py-2 rounded-lg font-bold text-sm hover:bg-white/10 transition-all flex items-center gap-2"
                        title="Renvoyer un mot de passe temporaire"
                    >
                        <Mail size={16} />
                        Renvoyer Identifiants
                    </button>
                    <button 
                        onClick={handleForceReset}
                        className="bg-white/5 border border-white/10 text-white px-4 py-2 rounded-lg font-bold text-sm hover:bg-white/10 transition-all flex items-center gap-2"
                        title="Envoyer un lien de réinitialisation"
                    >
                        <ShieldCheck size={16} />
                        Forcer Reset MDP
                    </button>
                    <button 
                        onClick={() => setEditMode(true)}
                        className="bg-white/5 border border-white/10 text-white px-4 py-2 rounded-lg font-bold text-sm hover:bg-white/10 transition-all flex items-center gap-2"
                    >
                        <Settings size={16} />
                        Éditer Profil
                    </button>
                    <button 
                        onClick={handleDeleteClient}
                        className="bg-red-500/10 text-red-400 px-4 py-2 rounded-lg font-bold text-sm hover:bg-red-500/20 transition-all flex items-center gap-2"
                    >
                        <Trash2 size={16} />
                        Supprimer
                    </button>
                </div>
            </header>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
                {/* Modules Provisioning */}
                <div className="lg:col-span-1 space-y-6">
                    <div className="bg-[#111111] rounded-2xl p-8 border border-white/5">
                        <h2 className="text-xl font-bold text-white mb-6 flex items-center gap-2">
                            <Briefcase size={20} className="text-orange-400" />
                            Événementiel
                        </h2>
                        <p className="text-sm text-gray-500 mb-6">Configurez les espaces et les catégories de staff autorisées pour ce client.</p>
                        <button 
                            onClick={() => setShowEvenementielConfig(true)}
                            className="w-full bg-white text-black py-3 rounded-xl font-bold hover:bg-gray-200 transition-all shadow-lg shadow-white/5"
                        >
                            Configurer le Module
                        </button>
                    </div>

                    <div className="bg-[#111111] rounded-2xl p-8 border border-white/5">
                        <h2 className="text-xl font-bold text-white mb-6 flex items-center gap-2">
                            <Settings size={20} className="text-purple-400" />
                            Provisioning
                        </h2>
                        <div className="space-y-4">
                            {modules.map((m) => (
                                <div 
                                    key={m.module_name}
                                    className="flex items-center justify-between p-4 rounded-xl bg-black border border-white/5"
                                >
                                    <span className="capitalize font-medium text-white">{m.module_name}</span>
                                    <button 
                                        onClick={() => handleUpdateModules(m.module_name, m.is_active === 0)}
                                        className="transition-all"
                                    >
                                        {m.is_active === 1 ? <ToggleRight size={32} className="text-white" /> : <ToggleLeft size={32} className="text-gray-700" />}
                                    </button>
                                </div>
                            ))}
                        </div>
                    </div>

                    <div className="bg-[#111111] rounded-2xl p-8 border border-white/5">
                        <h2 className="text-xl font-bold text-white mb-6 flex items-center gap-2">
                            <Briefcase size={20} className="text-orange-400" />
                            Événementiel
                        </h2>
                        <p className="text-sm text-gray-500 mb-6">Configurez les espaces et les catégories de staff autorisées pour ce client.</p>
                        <button 
                            onClick={() => setShowEvenementielConfig(true)}
                            className="w-full bg-white text-black py-3 rounded-xl font-bold hover:bg-gray-200 transition-all shadow-lg shadow-white/5"
                        >
                            Configurer le Module
                        </button>
                    </div>

                    <div className="bg-[#111111] rounded-2xl p-8 border border-white/5">
                        <h2 className="text-xl font-bold text-white mb-6 flex items-center gap-2">
                            <ShieldCheck size={20} className="text-blue-400" />
                            Audit & Sécurité
                        </h2>
                        <div className="space-y-4 text-sm">
                            <div className="flex justify-between py-2 border-b border-white/5">
                                <span className="text-gray-500">Dernière Connexion</span>
                                <span className="text-white font-medium">{client.last_login ? new Date(client.last_login).toLocaleString() : 'Jamais'}</span>
                            </div>
                            <div className="flex justify-between py-2 border-b border-white/5">
                                <span className="text-gray-500">Date de Création</span>
                                <span className="text-white font-medium">{new Date(client.created_at).toLocaleDateString()}</span>
                            </div>
                            <div className="flex justify-between py-2">
                                <span className="text-gray-500">Type de Compte</span>
                                <span className="text-white font-medium uppercase tracking-widest text-[10px] bg-white/5 px-2 py-0.5 rounded">Client SaaS</span>
                            </div>
                        </div>
                    </div>
                </div>

                {/* Collaborators */}
                <div className="lg:col-span-2 space-y-6">
                    <div className="bg-[#111111] rounded-2xl p-8 border border-white/5">
                        <div className="flex items-center justify-between mb-8">
                            <h2 className="text-xl font-bold text-white flex items-center gap-2">
                                <Users size={20} className="text-green-400" />
                                Collaborateurs
                            </h2>
                            <button 
                                onClick={() => setShowCollabModal(true)}
                                className="text-sm font-bold text-white hover:text-gray-300 flex items-center gap-2 transition-all"
                            >
                                <Plus size={16} /> Ajouter
                            </button>
                        </div>

                        <div className="overflow-hidden">
                            <table className="w-full text-left">
                                <thead>
                                    <tr className="text-xs font-bold text-gray-500 uppercase tracking-widest border-b border-white/5">
                                        <th className="pb-4">Nom</th>
                                        <th className="pb-4">Email</th>
                                        <th className="pb-4">Rôle</th>
                                        <th className="pb-4 text-right">Actions</th>
                                    </tr>
                                </thead>
                                <tbody className="divide-y divide-white/5">
                                    {collaborators.length === 0 ? (
                                        <tr><td colSpan={4} className="py-10 text-center text-gray-500">Aucun collaborateur.</td></tr>
                                    ) : collaborators.map((collab) => (
                                        <tr key={collab.id}>
                                            <td className="py-4 font-bold text-white">{collab.name}</td>
                                            <td className="py-4 text-gray-400">{collab.email}</td>
                                            <td className="py-4">
                                                <span className="text-[10px] font-bold uppercase tracking-widest bg-white/5 px-2 py-1 rounded text-gray-400">
                                                    {collab.role || 'Collaborateur'}
                                                </span>
                                            </td>
                                            <td className="py-4 text-right">
                                                <button className="text-gray-600 hover:text-red-500 transition-all">
                                                    <Trash2 size={16} />
                                                </button>
                                            </td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                    </div>

                    <div className="bg-[#111111] rounded-2xl p-8 border border-white/5">
                        <div className="flex items-center justify-between mb-8">
                            <h2 className="text-xl font-bold text-white flex items-center gap-2">
                                <MapPin size={20} className="text-orange-400" />
                                Espaces (Salles)
                            </h2>
                            <button 
                                onClick={() => setShowSpaceModal(true)}
                                className="text-sm font-bold text-white hover:text-gray-300 flex items-center gap-2 transition-all"
                            >
                                <Plus size={16} /> Ajouter un espace
                            </button>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            {spaces.length === 0 ? (
                                <p className="col-span-full py-10 text-center text-gray-500">Aucun espace configuré.</p>
                            ) : spaces.map((space) => (
                                <div key={space.id} className="flex items-center justify-between p-4 rounded-xl bg-black border border-white/5">
                                    <div className="flex items-center gap-3">
                                        <div className="w-4 h-4 rounded-full" style={{ backgroundColor: space.color }}></div>
                                        <span className="font-bold text-white">{space.name}</span>
                                    </div>
                                    <button 
                                        onClick={() => handleDeleteSpace(space.id)}
                                        className="text-gray-600 hover:text-red-500 transition-all"
                                    >
                                        <Trash2 size={16} />
                                    </button>
                                </div>
                            ))}
                        </div>
                    </div>
                </div>
            </div>

            {/* Modal Édition Profil */}
            <AnimatePresence>
                {editMode && (
                    <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-6">
                        <motion.div 
                            initial={{ opacity: 0, scale: 0.95 }}
                            animate={{ opacity: 1, scale: 1 }}
                            exit={{ opacity: 0, scale: 0.95 }}
                            className="w-full max-w-md bg-[#111111] rounded-2xl p-10 shadow-2xl border border-white/5"
                        >
                            <h2 className="text-2xl font-bold mb-8 text-white">Éditer le Profil</h2>
                            <form onSubmit={handleUpdateProfile} className="space-y-6">
                                <div className="space-y-2">
                                    <label className="text-xs font-bold text-gray-500 uppercase tracking-widest">Nom de l'entreprise</label>
                                    <input 
                                        type="text" required
                                        value={editData.name}
                                        onChange={(e) => setEditData({ ...editData, name: e.target.value })}
                                        className="w-full px-4 py-3 rounded-lg bg-black border border-white/10 text-white focus:border-white outline-none transition-all"
                                    />
                                </div>
                                <div className="space-y-2">
                                    <label className="text-xs font-bold text-gray-500 uppercase tracking-widest">Email de connexion</label>
                                    <input 
                                        type="email" required
                                        value={editData.email}
                                        onChange={(e) => setEditData({ ...editData, email: e.target.value })}
                                        className="w-full px-4 py-3 rounded-lg bg-black border border-white/10 text-white focus:border-white outline-none transition-all"
                                    />
                                </div>
                                <div className="flex gap-4 pt-4">
                                    <button 
                                        type="button"
                                        onClick={() => setEditMode(false)}
                                        className="flex-1 px-6 py-4 rounded-lg font-bold border border-white/10 text-white hover:bg-white/5 transition-all"
                                    >
                                        Annuler
                                    </button>
                                    <button 
                                        type="submit"
                                        className="flex-1 bg-white text-black px-6 py-4 rounded-lg font-bold hover:bg-gray-200 transition-all"
                                    >
                                        Enregistrer
                                    </button>
                                </div>
                            </form>
                        </motion.div>
                    </div>
                )}
            </AnimatePresence>

            {/* Modal Collaborateur */}
            <AnimatePresence>
                {showCollabModal && (
                    <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-6">
                        <motion.div 
                            initial={{ opacity: 0, scale: 0.95 }}
                            animate={{ opacity: 1, scale: 1 }}
                            exit={{ opacity: 0, scale: 0.95 }}
                            className="w-full max-w-md bg-[#111111] rounded-2xl p-10 shadow-2xl border border-white/5"
                        >
                            <h2 className="text-2xl font-bold mb-8 text-white">Nouveau Collaborateur</h2>
                            <form onSubmit={handleAddCollab} className="space-y-6">
                                <div className="space-y-2">
                                    <label className="text-xs font-bold text-gray-500 uppercase tracking-widest">Nom complet</label>
                                    <input 
                                        type="text" required
                                        value={newCollab.name}
                                        onChange={(e) => setNewCollab({ ...newCollab, name: e.target.value })}
                                        className="w-full px-4 py-3 rounded-lg bg-black border border-white/10 text-white focus:border-white outline-none transition-all"
                                    />
                                </div>
                                <div className="space-y-2">
                                    <label className="text-xs font-bold text-gray-500 uppercase tracking-widest">Email</label>
                                    <input 
                                        type="email" required
                                        value={newCollab.email}
                                        onChange={(e) => setNewCollab({ ...newCollab, email: e.target.value })}
                                        className="w-full px-4 py-3 rounded-lg bg-black border border-white/10 text-white focus:border-white outline-none transition-all"
                                    />
                                </div>
                                <div className="space-y-2">
                                    <label className="text-xs font-bold text-gray-500 uppercase tracking-widest">Rôle</label>
                                    <input 
                                        type="text" required
                                        value={newCollab.role}
                                        onChange={(e) => setNewCollab({ ...newCollab, role: e.target.value })}
                                        className="w-full px-4 py-3 rounded-lg bg-black border border-white/10 text-white focus:border-white outline-none transition-all"
                                        placeholder="ex: Manager, Serveur..."
                                    />
                                </div>
                                <div className="flex gap-4 pt-4">
                                    <button 
                                        type="button"
                                        onClick={() => setShowCollabModal(false)}
                                        className="flex-1 px-6 py-4 rounded-lg font-bold border border-white/10 text-white hover:bg-white/5 transition-all"
                                    >
                                        Annuler
                                    </button>
                                    <button 
                                        type="submit"
                                        className="flex-1 bg-white text-black px-6 py-4 rounded-lg font-bold hover:bg-gray-200 transition-all"
                                    >
                                        Créer
                                    </button>
                                </div>
                            </form>
                        </motion.div>
                    </div>
                )}
            </AnimatePresence>

            {/* Modal Espace */}
            <AnimatePresence>
                {showSpaceModal && (
                    <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-6">
                        <motion.div 
                            initial={{ opacity: 0, scale: 0.95 }}
                            animate={{ opacity: 1, scale: 1 }}
                            exit={{ opacity: 0, scale: 0.95 }}
                            className="w-full max-w-md bg-[#111111] rounded-2xl p-10 shadow-2xl border border-white/5"
                        >
                            <h2 className="text-2xl font-bold mb-8 text-white">Nouvel Espace</h2>
                            <form onSubmit={handleAddSpace} className="space-y-6">
                                <div className="space-y-2">
                                    <label className="text-xs font-bold text-gray-500 uppercase tracking-widest">Nom de la salle</label>
                                    <input 
                                        type="text" required
                                        value={newSpace.name}
                                        onChange={(e) => setNewSpace({ ...newSpace, name: e.target.value })}
                                        className="w-full px-4 py-3 rounded-lg bg-black border border-white/10 text-white focus:border-white outline-none transition-all"
                                        placeholder="ex: RDC, Salon VIP..."
                                    />
                                </div>
                                <div className="space-y-2">
                                    <label className="text-xs font-bold text-gray-500 uppercase tracking-widest">Couleur sur le calendrier</label>
                                    <div className="flex gap-3">
                                        <input 
                                            type="color"
                                            value={newSpace.color}
                                            onChange={(e) => setNewSpace({ ...newSpace, color: e.target.value })}
                                            className="w-12 h-12 rounded bg-black border border-white/10 cursor-pointer"
                                        />
                                        <input 
                                            type="text"
                                            value={newSpace.color}
                                            onChange={(e) => setNewSpace({ ...newSpace, color: e.target.value })}
                                            className="flex-1 px-4 py-3 rounded-lg bg-black border border-white/10 text-white focus:border-white outline-none transition-all font-mono"
                                        />
                                    </div>
                                </div>
                                <div className="flex gap-4 pt-4">
                                    <button 
                                        type="button"
                                        onClick={() => setShowSpaceModal(false)}
                                        className="flex-1 px-6 py-4 rounded-lg font-bold border border-white/10 text-white hover:bg-white/5 transition-all"
                                    >
                                        Annuler
                                    </button>
                                    <button 
                                        type="submit"
                                        className="flex-1 bg-white text-black px-6 py-4 rounded-lg font-bold hover:bg-gray-200 transition-all"
                                    >
                                        Ajouter
                                    </button>
                                </div>
                            </form>
                        </motion.div>
                    </div>
                )}
            </AnimatePresence>
        </div>
    );
};

const EvenementielView = () => {
    const { user } = useAuth();
    const [calendars, setCalendars] = React.useState<any[]>([]);
    const [selectedCalendar, setSelectedCalendar] = React.useState<any | null>(null);
    const [events, setEvents] = React.useState<any[]>([]);
    const [spaces, setSpaces] = React.useState<any[]>([]);
    const [staffTypes, setStaffTypes] = React.useState<any[]>([]);
    const [loading, setLoading] = React.useState(true);
    const [showEventModal, setShowEventModal] = React.useState(false);
    const [showCalendarModal, setShowCalendarModal] = React.useState(false);
    const [showSettingsModal, setShowSettingsModal] = React.useState(false);
    const [filter, setFilter] = React.useState('ALL');
    const [spaceFilter, setSpaceFilter] = React.useState('ALL');
    const [creationStep, setCreationStep] = React.useState(1);
    
    // Settings state
    const [newSpace, setNewSpace] = React.useState({ name: '', color: '#ffffff' });
    const [newStaffType, setNewStaffType] = React.useState({ name: '' });

    const [newCalendar, setNewCalendar] = React.useState({
        month: new Date().getMonth() + 1,
        year: new Date().getFullYear()
    });

    const [newEvent, setNewEvent] = React.useState<any>({
        type: 'PRIVÉ',
        phone: '',
        email: '',
        address: '',
        start_time: '',
        end_time: '',
        num_people: '',
        staff_requests: {}, // { staff_type_id: count }
        first_name: '',
        last_name: '',
        company_name: '',
        organizer_name: '',
        space_ids: []
    });

    React.useEffect(() => {
        loadInitialData();
    }, []);

    const loadInitialData = async () => {
        try {
            setLoading(true);
            const [cals, sps, stf] = await Promise.all([
                moduleApi.getEvenementielCalendars(),
                moduleApi.getEvenementielSpaces(),
                moduleApi.getEvenementielStaffTypes()
            ]);
            setCalendars(cals);
            setSpaces(sps);
            setStaffTypes(stf);
        } catch (e) {
            console.error(e);
        } finally {
            setLoading(false);
        }
    };

    const loadEvents = async (calendarId: string) => {
        try {
            setLoading(true);
            const data = await moduleApi.getEvenementielCalendarEvents(calendarId);
            setEvents(data);
        } catch (e) {
            console.error(e);
        } finally {
            setLoading(false);
        }
    };

    const handleOpenCalendar = (calendar: any) => {
        setSelectedCalendar(calendar);
        loadEvents(calendar.id);
    };

    const handleCreateCalendar = async (e: React.FormEvent) => {
        e.preventDefault();
        try {
            await moduleApi.createEvenementielCalendar(newCalendar);
            setShowCalendarModal(false);
            loadInitialData();
        } catch (e) {
            alert('Erreur lors de la création du calendrier');
        }
    };

    const handleCreateStaffType = async (e: React.FormEvent) => {
        e.preventDefault();
        try {
            await moduleApi.createEvenementielStaffType(newStaffType);
            setNewStaffType({ name: '' });
            loadInitialData();
        } catch (e) {
            alert('Erreur lors de la création du type de staff');
        }
    };

    const handleDeleteStaffType = async (id: string) => {
        if (!confirm('Supprimer ce type de staff ?')) return;
        try {
            await moduleApi.deleteEvenementielStaffType(id);
            loadInitialData();
        } catch (e) {
            alert('Erreur lors de la suppression');
        }
    };

    const handleCreateEvent = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!selectedCalendar) return;
        try {
            await moduleApi.createEvenementiel({
                ...newEvent,
                calendar_id: selectedCalendar.id
            });
            setShowEventModal(false);
            setCreationStep(1);
            setNewEvent({
                type: 'PRIVÉ',
                phone: '',
                email: '',
                address: '',
                start_time: '',
                end_time: '',
                num_people: '',
                staff_requests: {},
                first_name: '',
                last_name: '',
                company_name: '',
                organizer_name: '',
                space_ids: []
            });
            loadEvents(selectedCalendar.id);
        } catch (e: any) {
            alert(e.message || 'Erreur lors de la création de l\'événement');
        }
    };

    const handleDeleteEvent = async (id: string) => {
        if (!confirm('Supprimer cet événement ?')) return;
        try {
            await moduleApi.deleteEvenementiel(id);
            if (selectedCalendar) loadEvents(selectedCalendar.id);
        } catch (e) {
            alert('Erreur lors de la suppression');
        }
    };

    const months = [
        "Janvier", "Février", "Mars", "Avril", "Mai", "Juin",
        "Juillet", "Août", "Septembre", "Octobre", "Novembre", "Décembre"
    ];

    const filteredEvents = events.filter(e => {
        const typeMatch = filter === 'ALL' || e.type === filter;
        const spaceMatch = spaceFilter === 'ALL' || (e.spaces && e.spaces.some((s: any) => s.id === spaceFilter));
        return typeMatch && spaceMatch;
    });

    if (!selectedCalendar) {
        return (
            <div className="space-y-8">
                <header className="flex items-center justify-between">
                    <div>
                        <h1 className="text-3xl font-bold tracking-tight text-white">Événementiel</h1>
                        <p className="text-gray-500 mt-1">Sélectionnez un calendrier mensuel pour gérer vos événements.</p>
                    </div>
                    <div className="flex gap-3">
                        <button 
                            onClick={() => setShowSettingsModal(true)}
                            className="bg-[#111111] border border-white/10 text-white px-4 py-3 rounded-lg font-bold flex items-center gap-2 hover:bg-white/5 transition-all"
                        >
                            <Settings size={20} />
                            <span>Configuration</span>
                        </button>
                        <button 
                            onClick={() => setShowCalendarModal(true)}
                            className="bg-white text-black px-6 py-3 rounded-lg font-bold flex items-center gap-2 shadow-lg shadow-white/5 hover:bg-gray-200 transition-all"
                        >
                            <Plus size={20} />
                            <span>Nouveau Calendrier</span>
                        </button>
                    </div>
                </header>

                {loading ? (
                    <div className="flex justify-center py-20 text-gray-500">Chargement...</div>
                ) : calendars.length === 0 ? (
                    <div className="bg-[#111111] rounded-2xl border border-white/5 p-20 flex flex-col items-center justify-center text-center">
                        <div className="w-20 h-20 bg-white/5 rounded-full flex items-center justify-center mb-6">
                            <Calendar size={40} className="text-gray-700" />
                        </div>
                        <h3 className="text-xl font-bold mb-2 text-white">Aucun calendrier</h3>
                        <p className="text-gray-500 max-w-sm">Créez votre premier calendrier mensuel pour commencer à ajouter des privatisations.</p>
                    </div>
                ) : (
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                        {calendars.map((cal) => (
                            <motion.div 
                                key={cal.id}
                                initial={{ opacity: 0, y: 10 }}
                                animate={{ opacity: 1, y: 0 }}
                                onClick={() => handleOpenCalendar(cal)}
                                className="bg-[#111111] rounded-2xl border border-white/5 p-8 hover:border-white/20 transition-all cursor-pointer group relative overflow-hidden"
                            >
                                <div className="relative z-10">
                                    <div className="flex justify-between items-start mb-6">
                                        <div className="w-12 h-12 bg-white/5 rounded-xl flex items-center justify-center border border-white/10">
                                            <Calendar className="text-white" size={24} />
                                        </div>
                                        <span className={`text-[10px] font-bold px-2 py-1 rounded uppercase tracking-widest ${
                                            cal.status === 'OPEN' ? 'bg-green-500/10 text-green-400' : 'bg-gray-500/10 text-gray-400'
                                        }`}>
                                            {cal.status === 'OPEN' ? 'Ouvert' : 'Archivé'}
                                        </span>
                                    </div>
                                    <h3 className="text-2xl font-bold text-white">{months[cal.month - 1]}</h3>
                                    <p className="text-gray-500 font-medium">{cal.year}</p>
                                    
                                    <div className="mt-8 flex items-center gap-2 text-sm font-bold text-white group-hover:translate-x-1 transition-all">
                                        Ouvrir le planning <ChevronRight size={16} />
                                    </div>
                                </div>
                                <div className="absolute -right-4 -bottom-4 w-24 h-24 bg-white/5 rounded-full blur-2xl group-hover:bg-white/10 transition-all"></div>
                            </motion.div>
                        ))}
                    </div>
                )}

                {/* Modal Nouveau Calendrier */}
                <AnimatePresence>
                    {showCalendarModal && (
                        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-6">
                            <motion.div 
                                initial={{ opacity: 0, scale: 0.95 }}
                                animate={{ opacity: 1, scale: 1 }}
                                exit={{ opacity: 0, scale: 0.95 }}
                                className="w-full max-w-md bg-[#111111] rounded-2xl p-10 shadow-2xl border border-white/5"
                            >
                                <h2 className="text-2xl font-bold mb-8 text-white">Nouveau Calendrier</h2>
                                <form onSubmit={handleCreateCalendar} className="space-y-6">
                                    <div className="space-y-2">
                                        <label className="text-xs font-bold text-gray-500 uppercase tracking-widest">Mois</label>
                                        <select 
                                            value={newCalendar.month}
                                            onChange={(e) => setNewCalendar({...newCalendar, month: parseInt(e.target.value)})}
                                            className="w-full px-4 py-3 rounded-lg bg-black border border-white/10 text-white focus:border-white outline-none transition-all"
                                        >
                                            {months.map((m, i) => (
                                                <option key={i} value={i + 1}>{m}</option>
                                            ))}
                                        </select>
                                    </div>
                                    <div className="space-y-2">
                                        <label className="text-xs font-bold text-gray-500 uppercase tracking-widest">Année</label>
                                        <input 
                                            type="number" required
                                            value={newCalendar.year}
                                            onChange={(e) => setNewCalendar({...newCalendar, year: parseInt(e.target.value)})}
                                            className="w-full px-4 py-3 rounded-lg bg-black border border-white/10 text-white focus:border-white outline-none transition-all"
                                        />
                                    </div>
                                    <div className="flex gap-4 pt-4">
                                        <button 
                                            type="button"
                                            onClick={() => setShowCalendarModal(false)}
                                            className="flex-1 px-6 py-4 rounded-lg font-bold border border-white/10 text-white hover:bg-white/5 transition-all"
                                        >
                                            Annuler
                                        </button>
                                        <button 
                                            type="submit"
                                            className="flex-1 bg-white text-black px-6 py-4 rounded-lg font-bold hover:bg-gray-200 transition-all"
                                        >
                                            Créer
                                        </button>
                                    </div>
                                </form>
                            </motion.div>
                        </div>
                    )}

                    {showSettingsModal && (
                        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-6 overflow-y-auto">
                            <motion.div 
                                initial={{ opacity: 0, scale: 0.95 }}
                                animate={{ opacity: 1, scale: 1 }}
                                exit={{ opacity: 0, scale: 0.95 }}
                                className="w-full max-w-4xl bg-[#111111] rounded-2xl p-10 shadow-2xl border border-white/5 my-auto"
                            >
                                <div className="flex justify-between items-center mb-8">
                                    <h2 className="text-2xl font-bold text-white">Configuration du module</h2>
                                    <button onClick={() => setShowSettingsModal(false)} className="text-gray-500 hover:text-white">Fermer</button>
                                </div>

                                <div className="grid grid-cols-1 gap-12">
                                    {/* Gestion du Staff */}
                                    <div className="space-y-6">
                                        <h3 className="text-lg font-bold text-white flex items-center gap-2">
                                            <UserCheck size={20} className="text-purple-400" />
                                            Types de Staff
                                        </h3>
                                        <form onSubmit={handleCreateStaffType} className="flex gap-2">
                                            <input 
                                                type="text" required placeholder="ex: Serveur, Sécurité..."
                                                value={newStaffType.name}
                                                onChange={(e) => setNewStaffType({...newStaffType, name: e.target.value})}
                                                className="flex-1 px-4 py-2 rounded-lg bg-black border border-white/10 text-white focus:border-white outline-none transition-all text-sm"
                                            />
                                            <button type="submit" className="bg-white text-black px-4 py-2 rounded-lg font-bold text-sm hover:bg-gray-200 transition-all">
                                                Ajouter
                                            </button>
                                        </form>
                                        <div className="space-y-2 max-h-60 overflow-y-auto pr-2">
                                            {staffTypes.map(st => (
                                                <div key={st.id} className="flex items-center justify-between p-3 bg-black rounded-lg border border-white/5">
                                                    <span className="text-white text-sm">{st.name}</span>
                                                    <button onClick={() => handleDeleteStaffType(st.id)} className="text-gray-600 hover:text-red-500 transition-all">
                                                        <Trash2 size={14} />
                                                    </button>
                                                </div>
                                            ))}
                                        </div>
                                    </div>
                                </div>
                            </motion.div>
                        </div>
                    )}
                </AnimatePresence>
            </div>
        );
    }

    return (
        <div className="space-y-8">
            <header className="flex flex-col md:flex-row md:items-center justify-between gap-6">
                <div>
                    <button 
                        onClick={() => setSelectedCalendar(null)}
                        className="text-sm text-gray-500 hover:text-white flex items-center gap-1 mb-2 transition-all"
                    >
                        <ChevronRight size={14} className="rotate-180" /> Retour aux calendriers
                    </button>
                    <h1 className="text-3xl font-bold tracking-tight text-white">
                        Planning {months[selectedCalendar.month - 1]} {selectedCalendar.year}
                    </h1>
                    <div className="flex items-center gap-2 mt-1">
                        <span className={`w-2 h-2 rounded-full ${selectedCalendar.status === 'OPEN' ? 'bg-green-500' : 'bg-gray-500'}`}></span>
                        <p className="text-gray-500 text-sm font-medium">
                            Statut: {selectedCalendar.status === 'OPEN' ? 'Ouvert (Modifications autorisées)' : 'Archivé (Lecture seule)'}
                        </p>
                    </div>
                </div>
                <div className="flex flex-wrap gap-3">
                    <select 
                        value={spaceFilter}
                        onChange={(e) => setSpaceFilter(e.target.value)}
                        className="bg-[#111111] border border-white/10 text-white px-4 py-2 rounded-lg outline-none focus:border-white transition-all text-sm font-medium"
                    >
                        <option value="ALL">Tous les espaces</option>
                        {spaces.map(s => (
                            <option key={s.id} value={s.id}>{s.name}</option>
                        ))}
                    </select>
                    <select 
                        value={filter}
                        onChange={(e) => setFilter(e.target.value)}
                        className="bg-[#111111] border border-white/10 text-white px-4 py-2 rounded-lg outline-none focus:border-white transition-all text-sm font-medium"
                    >
                        <option value="ALL">Tous les types</option>
                        <option value="PRIVÉ">Privé</option>
                        <option value="PROFESSIONNEL">Professionnel</option>
                    </select>
                    {selectedCalendar.status === 'OPEN' && (
                        <button 
                            onClick={() => setShowEventModal(true)}
                            className="bg-white text-black px-6 py-3 rounded-lg font-bold flex items-center gap-2 shadow-lg shadow-white/5 hover:bg-gray-200 transition-all"
                        >
                            <Plus size={20} />
                            <span>Nouvelle Privatisation</span>
                        </button>
                    )}
                </div>
            </header>

            {loading ? (
                <div className="flex justify-center py-20 text-gray-500">Chargement...</div>
            ) : filteredEvents.length === 0 ? (
                <div className="bg-[#111111] rounded-2xl border border-white/5 p-20 flex flex-col items-center justify-center text-center">
                    <div className="w-20 h-20 bg-white/5 rounded-full flex items-center justify-center mb-6">
                        <Briefcase size={40} className="text-gray-700" />
                    </div>
                    <h3 className="text-xl font-bold mb-2 text-white">Aucun événement ce mois-ci</h3>
                    <p className="text-gray-500 max-w-sm">
                        {selectedCalendar.status === 'OPEN' 
                            ? 'Commencez par ajouter votre première privatisation pour ce calendrier.' 
                            : 'Ce calendrier est archivé et ne contient aucun événement.'}
                    </p>
                </div>
            ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {filteredEvents.map((event) => (
                        <motion.div 
                            key={event.id}
                            initial={{ opacity: 0, y: 10 }}
                            animate={{ opacity: 1, y: 0 }}
                            className="bg-[#111111] rounded-2xl border border-white/5 p-6 hover:border-white/20 transition-all group"
                        >
                            <div className="flex justify-between items-start mb-4">
                                <div className="flex flex-wrap gap-1">
                                    <span className={`text-[10px] font-bold px-2 py-1 rounded uppercase tracking-widest ${
                                        event.type === 'PRIVÉ' ? 'bg-blue-500/10 text-blue-400' : 'bg-purple-500/10 text-purple-400'
                                    }`}>
                                        {event.type}
                                    </span>
                                    {event.spaces?.map((s: any) => (
                                        <span key={s.id} className="text-[10px] font-bold px-2 py-1 rounded uppercase tracking-widest bg-white/5 text-white flex items-center gap-1">
                                            <div className="w-1.5 h-1.5 rounded-full" style={{ backgroundColor: s.color }}></div>
                                            {s.name}
                                        </span>
                                    ))}
                                </div>
                                {selectedCalendar.status === 'OPEN' && (
                                    <button 
                                        onClick={() => handleDeleteEvent(event.id)}
                                        className="text-gray-600 hover:text-red-500 opacity-0 group-hover:opacity-100 transition-all"
                                    >
                                        <Trash2 size={16} />
                                    </button>
                                )}
                            </div>
                            
                            <h3 className="text-lg font-bold text-white mb-1">
                                {event.type === 'PRIVÉ' ? `${event.first_name} ${event.last_name}` : event.company_name}
                            </h3>
                            {event.type === 'PROFESSIONNEL' && (
                                <p className="text-xs text-gray-500 mb-3">Org: {event.organizer_name}</p>
                            )}
                            
                            <div className="space-y-3 mt-4">
                                <div className="flex items-center gap-3 text-sm text-gray-400">
                                    <Calendar size={14} />
                                    <span>{new Date(event.start_time).toLocaleDateString()}</span>
                                </div>
                                <div className="flex items-center gap-3 text-sm text-gray-400">
                                    <FileText size={14} />
                                    <span>{new Date(event.start_time).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})} - {new Date(event.end_time).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}</span>
                                </div>
                                {event.num_people && (
                                    <div className="flex items-center gap-3 text-sm text-gray-400">
                                        <Users size={14} />
                                        <span>{event.num_people} personnes</span>
                                    </div>
                                )}
                                <div className="flex items-center gap-3 text-sm text-gray-400">
                                    <Mail size={14} />
                                    <span>{event.phone}</span>
                                </div>
                                {event.staff?.length > 0 && (
                                    <div className="pt-3 border-t border-white/5 mt-3">
                                        <p className="text-[10px] font-bold text-gray-600 uppercase tracking-widest mb-2">Staff demandé</p>
                                        <div className="flex flex-wrap gap-2">
                                            {event.staff.map((s: any, i: number) => (
                                                <span key={i} className="text-[10px] text-gray-400 bg-white/5 px-2 py-1 rounded">
                                                    {s.count}x {s.name}
                                                </span>
                                            ))}
                                        </div>
                                    </div>
                                )}
                            </div>
                        </motion.div>
                    ))}
                </div>
            )}

            {/* Modal de création d'événement */}
            <AnimatePresence>
                {showEventModal && (
                    <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-6 overflow-y-auto">
                        <motion.div 
                            initial={{ opacity: 0, scale: 0.95 }}
                            animate={{ opacity: 1, scale: 1 }}
                            exit={{ opacity: 0, scale: 0.95 }}
                            className="w-full max-w-2xl bg-[#111111] rounded-2xl p-10 shadow-2xl border border-white/5 my-auto"
                        >
                            <div className="flex justify-between items-center mb-8">
                                <div>
                                    <h2 className="text-2xl font-bold text-white">Nouvelle Privatisation</h2>
                                    <p className="text-gray-500 text-sm">Étape {creationStep} sur 2</p>
                                </div>
                                <button onClick={() => { setShowEventModal(false); setCreationStep(1); }} className="text-gray-500 hover:text-white">Fermer</button>
                            </div>

                            {creationStep === 1 ? (
                                <div className="space-y-8">
                                    <div className="space-y-4">
                                        <h3 className="text-lg font-bold text-white flex items-center gap-2">
                                            <MapPin size={20} className="text-blue-400" />
                                            1. Sélection des espaces (Obligatoire)
                                        </h3>
                                        <p className="text-gray-500 text-sm">Choisissez un ou plusieurs espaces pour cet événement.</p>
                                        <div className="grid grid-cols-2 gap-4">
                                            {spaces.map(space => (
                                                <button
                                                    key={space.id}
                                                    type="button"
                                                    onClick={() => {
                                                        const ids = newEvent.space_ids.includes(space.id)
                                                            ? newEvent.space_ids.filter((id: string) => id !== space.id)
                                                            : [...newEvent.space_ids, space.id];
                                                        setNewEvent({...newEvent, space_ids: ids});
                                                    }}
                                                    className={`p-4 rounded-xl border transition-all text-left flex items-center gap-3 ${
                                                        newEvent.space_ids.includes(space.id)
                                                            ? 'bg-white/10 border-white text-white'
                                                            : 'bg-black border-white/5 text-gray-500 hover:border-white/20'
                                                    }`}
                                                >
                                                    <div className="w-4 h-4 rounded-full" style={{ backgroundColor: space.color }}></div>
                                                    <span className="font-bold">{space.name}</span>
                                                </button>
                                            ))}
                                        </div>
                                        {spaces.length === 0 && (
                                            <div className="p-4 bg-blue-500/10 border border-blue-500/20 rounded-lg text-blue-400 text-sm">
                                                Aucun espace configuré. Contactez l'administrateur pour configurer vos espaces.
                                            </div>
                                        )}
                                    </div>
                                    <button
                                        disabled={newEvent.space_ids.length === 0}
                                        onClick={() => setCreationStep(2)}
                                        className="w-full bg-white text-black py-4 rounded-lg font-bold hover:bg-gray-200 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
                                    >
                                        Continuer vers les détails
                                    </button>
                                </div>
                            ) : (
                                <form onSubmit={handleCreateEvent} className="space-y-8">
                                    <div className="space-y-6">
                                        <h3 className="text-lg font-bold text-white flex items-center gap-2">
                                            <FileText size={20} className="text-purple-400" />
                                            2. Détails de l'événement
                                        </h3>
                                        
                                        <div className="flex gap-4 p-1 bg-black rounded-xl border border-white/5">
                                            <button 
                                                type="button"
                                                onClick={() => setNewEvent({...newEvent, type: 'PRIVÉ'})}
                                                className={`flex-1 py-3 rounded-lg font-bold text-sm transition-all ${newEvent.type === 'PRIVÉ' ? 'bg-white text-black' : 'text-gray-500 hover:text-white'}`}
                                            >
                                                Événement PRIVÉ
                                            </button>
                                            <button 
                                                type="button"
                                                onClick={() => setNewEvent({...newEvent, type: 'PROFESSIONNEL'})}
                                                className={`flex-1 py-3 rounded-lg font-bold text-sm transition-all ${newEvent.type === 'PROFESSIONNEL' ? 'bg-white text-black' : 'text-gray-500 hover:text-white'}`}
                                            >
                                                Événement PROFESSIONNEL
                                            </button>
                                        </div>

                                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                            {newEvent.type === 'PRIVÉ' ? (
                                                <>
                                                    <div className="space-y-2">
                                                        <label className="text-xs font-bold text-gray-500 uppercase tracking-widest">Prénom *</label>
                                                        <input 
                                                            type="text" required
                                                            value={newEvent.first_name}
                                                            onChange={(e) => setNewEvent({...newEvent, first_name: e.target.value})}
                                                            className="w-full px-4 py-3 rounded-lg bg-black border border-white/10 text-white focus:border-white outline-none transition-all"
                                                        />
                                                    </div>
                                                    <div className="space-y-2">
                                                        <label className="text-xs font-bold text-gray-500 uppercase tracking-widest">Nom *</label>
                                                        <input 
                                                            type="text" required
                                                            value={newEvent.last_name}
                                                            onChange={(e) => setNewEvent({...newEvent, last_name: e.target.value})}
                                                            className="w-full px-4 py-3 rounded-lg bg-black border border-white/10 text-white focus:border-white outline-none transition-all"
                                                        />
                                                    </div>
                                                </>
                                            ) : (
                                                <>
                                                    <div className="space-y-2">
                                                        <label className="text-xs font-bold text-gray-500 uppercase tracking-widest">Nom Entreprise *</label>
                                                        <input 
                                                            type="text" required
                                                            value={newEvent.company_name}
                                                            onChange={(e) => setNewEvent({...newEvent, company_name: e.target.value})}
                                                            className="w-full px-4 py-3 rounded-lg bg-black border border-white/10 text-white focus:border-white outline-none transition-all"
                                                        />
                                                    </div>
                                                    <div className="space-y-2">
                                                        <label className="text-xs font-bold text-gray-500 uppercase tracking-widest">Nom Organisateur *</label>
                                                        <input 
                                                            type="text" required
                                                            value={newEvent.organizer_name}
                                                            onChange={(e) => setNewEvent({...newEvent, organizer_name: e.target.value})}
                                                            className="w-full px-4 py-3 rounded-lg bg-black border border-white/10 text-white focus:border-white outline-none transition-all"
                                                        />
                                                    </div>
                                                </>
                                            )}

                                            <div className="space-y-2">
                                                <label className="text-xs font-bold text-gray-500 uppercase tracking-widest">Téléphone *</label>
                                                <input 
                                                    type="tel" required
                                                    value={newEvent.phone}
                                                    onChange={(e) => setNewEvent({...newEvent, phone: e.target.value})}
                                                    className="w-full px-4 py-3 rounded-lg bg-black border border-white/10 text-white focus:border-white outline-none transition-all"
                                                />
                                            </div>
                                            <div className="space-y-2">
                                                <label className="text-xs font-bold text-gray-500 uppercase tracking-widest">Nombre de personnes {newEvent.type === 'PRIVÉ' ? '*' : ''}</label>
                                                <input 
                                                    type="number" required={newEvent.type === 'PRIVÉ'}
                                                    value={newEvent.num_people}
                                                    onChange={(e) => setNewEvent({...newEvent, num_people: e.target.value})}
                                                    className="w-full px-4 py-3 rounded-lg bg-black border border-white/10 text-white focus:border-white outline-none transition-all"
                                                />
                                            </div>

                                            <div className="space-y-2">
                                                <label className="text-xs font-bold text-gray-500 uppercase tracking-widest">Heure Début *</label>
                                                <input 
                                                    type="datetime-local" required
                                                    value={newEvent.start_time}
                                                    onChange={(e) => setNewEvent({...newEvent, start_time: e.target.value})}
                                                    className="w-full px-4 py-3 rounded-lg bg-black border border-white/10 text-white focus:border-white outline-none transition-all"
                                                />
                                            </div>
                                            <div className="space-y-2">
                                                <label className="text-xs font-bold text-gray-500 uppercase tracking-widest">Heure Fin *</label>
                                                <input 
                                                    type="datetime-local" required
                                                    value={newEvent.end_time}
                                                    onChange={(e) => setNewEvent({...newEvent, end_time: e.target.value})}
                                                    className="w-full px-4 py-3 rounded-lg bg-black border border-white/10 text-white focus:border-white outline-none transition-all"
                                                />
                                            </div>
                                        </div>

                                        {/* Staff Requests */}
                                        <div className="space-y-4 pt-4 border-t border-white/5">
                                            <h4 className="text-sm font-bold text-white flex items-center gap-2">
                                                <UserCheck size={16} className="text-gray-400" />
                                                Demandes de Staff
                                            </h4>
                                            <div className="grid grid-cols-2 gap-4">
                                                {staffTypes.map(st => (
                                                    <div key={st.id} className="flex items-center justify-between p-3 bg-black rounded-lg border border-white/5">
                                                        <span className="text-xs text-gray-400">{st.name}</span>
                                                        <input 
                                                            type="number" min="0"
                                                            value={newEvent.staff_requests[st.id] || 0}
                                                            onChange={(e) => setNewEvent({
                                                                ...newEvent, 
                                                                staff_requests: {
                                                                    ...newEvent.staff_requests,
                                                                    [st.id]: parseInt(e.target.value) || 0
                                                                }
                                                            })}
                                                            className="w-16 px-2 py-1 rounded bg-[#111111] border border-white/10 text-white text-xs outline-none focus:border-white"
                                                        />
                                                    </div>
                                                ))}
                                            </div>
                                        </div>
                                    </div>

                                    <div className="flex gap-4 pt-4">
                                        <button 
                                            type="button"
                                            onClick={() => setCreationStep(1)}
                                            className="flex-1 px-6 py-4 rounded-lg font-bold border border-white/10 text-white hover:bg-white/5 transition-all"
                                        >
                                            Retour
                                        </button>
                                        <button 
                                            type="submit"
                                            className="flex-1 bg-white text-black px-6 py-4 rounded-lg font-bold hover:bg-gray-200 transition-all"
                                        >
                                            Enregistrer
                                        </button>
                                    </div>
                                </form>
                            )}
                        </motion.div>
                    </div>
                )}
            </AnimatePresence>
        </div>
    );
};

const ModulePlaceholder = ({ title, icon: Icon }: any) => (
    <div className="space-y-8">
        <header className="flex items-center justify-between">
            <div>
                <h1 className="text-3xl font-bold tracking-tight text-white">{title}</h1>
                <p className="text-gray-500 mt-1">Gérez vos données de {title.toLowerCase()}.</p>
            </div>
            <div className="flex gap-3">
                <button className="bg-[#111111] border border-white/5 p-3 rounded-lg hover:bg-white/5 transition-all text-white">
                    <Filter size={20} className="text-gray-500" />
                </button>
                <button className="bg-[#111111] border border-white/5 p-3 rounded-lg hover:bg-white/5 transition-all text-white">
                    <Download size={20} className="text-gray-500" />
                </button>
                <button className="bg-white text-black px-6 py-3 rounded-lg font-bold flex items-center gap-2 shadow-lg shadow-white/5 hover:bg-gray-200 transition-all">
                    <Plus size={20} />
                    <span>Nouveau</span>
                </button>
            </div>
        </header>

        <div className="bg-[#111111] rounded-2xl border border-white/5 shadow-sm p-12 flex flex-col items-center justify-center text-center">
            <div className="w-20 h-20 bg-white/5 rounded-full flex items-center justify-center mb-6 border border-white/10">
                <Icon size={40} className="text-gray-600" />
            </div>
            <h3 className="text-xl font-bold mb-2 text-white">Aucune donnée trouvée</h3>
            <p className="text-gray-500 max-w-sm">Commencez par ajouter votre premier élément de {title.toLowerCase()} pour voir les statistiques et graphiques.</p>
        </div>
    </div>
);

const ChangePasswordView = () => {
    const [newPassword, setNewPassword] = React.useState('');
    const [confirmPassword, setConfirmPassword] = React.useState('');
    const [error, setError] = React.useState('');
    const { logout } = useAuth();
    const navigate = useNavigate();

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (newPassword !== confirmPassword) {
            setError('Les mots de passe ne correspondent pas');
            return;
        }
        try {
            await authApi.changePassword(newPassword);
            alert('Mot de passe mis à jour avec succès. Veuillez vous reconnecter.');
            logout();
            navigate('/login');
        } catch (err: any) {
            setError(err.message);
        }
    };

    return (
        <div className="min-h-screen bg-[#0A0A0A] flex items-center justify-center p-6">
            <motion.div 
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                className="w-full max-w-md bg-[#111111] rounded-2xl shadow-2xl p-10 border border-white/5"
            >
                <div className="flex flex-col items-center mb-10">
                    <div className="w-12 h-12 bg-white rounded-xl flex items-center justify-center mb-4">
                        <Lock className="text-black" size={28} />
                    </div>
                    <h1 className="text-2xl font-bold tracking-tight text-white">Changer le mot de passe</h1>
                    <p className="text-gray-500 text-sm mt-2 text-center">Vous devez changer votre mot de passe temporaire avant de continuer.</p>
                </div>

                <form onSubmit={handleSubmit} className="space-y-6">
                    {error && (
                        <div className="p-4 bg-red-500/10 text-red-400 text-sm rounded-lg flex items-center gap-2 border border-red-500/20">
                            <XCircle size={16} />
                            {error}
                        </div>
                    )}
                    <div className="space-y-2">
                        <label className="text-xs font-bold text-gray-500 uppercase tracking-widest">Nouveau mot de passe</label>
                        <input 
                            type="password" 
                            value={newPassword}
                            onChange={(e) => setNewPassword(e.target.value)}
                            className="w-full px-4 py-3 rounded-lg bg-black border border-white/10 text-white focus:border-white focus:ring-0 transition-all outline-none"
                            required
                        />
                    </div>
                    <div className="space-y-2">
                        <label className="text-xs font-bold text-gray-500 uppercase tracking-widest">Confirmer le mot de passe</label>
                        <input 
                            type="password" 
                            value={confirmPassword}
                            onChange={(e) => setConfirmPassword(e.target.value)}
                            className="w-full px-4 py-3 rounded-lg bg-black border border-white/10 text-white focus:border-white focus:ring-0 transition-all outline-none"
                            required
                        />
                    </div>
                    <button 
                        type="submit"
                        className="w-full bg-white text-black py-4 rounded-lg font-bold hover:bg-gray-200 transition-all shadow-lg shadow-white/5"
                    >
                        Mettre à jour
                    </button>
                </form>
            </motion.div>
        </div>
    );
};

// --- App Component ---

const PrivateRoute = ({ children }: { children: React.ReactNode }) => {
    const { token, user, loading } = useAuth();
    if (loading) return <div>Chargement...</div>;
    
    if (!token) return <Navigate to="/login" />;
    
    // Force password change if temporary
    const payload = JSON.parse(atob(token.split('.')[1]));
    if (payload.isTemporary && window.location.pathname !== '/change-password') {
        return <Navigate to="/change-password" />;
    }
    
    return <Layout>{children}</Layout>;
};

class ErrorBoundary extends React.Component<{ children: React.ReactNode }, { hasError: boolean, error: any }> {
    constructor(props: any) {
        super(props);
        this.state = { hasError: false, error: null };
    }

    static getDerivedStateFromError(error: any) {
        return { hasError: true, error };
    }

    componentDidCatch(error: any, errorInfo: any) {
        console.error("Uncaught error:", error, errorInfo);
    }

    render() {
        if (this.state.hasError) {
            return (
                <div className="min-h-screen bg-black text-white flex flex-col items-center justify-center p-10 text-center">
                    <XCircle size={48} className="text-red-500 mb-4" />
                    <h1 className="text-2xl font-bold mb-2">Une erreur est survenue</h1>
                    <p className="text-gray-400 mb-6 max-w-md">
                        L'application n'a pas pu se charger correctement. 
                        Veuillez rafraîchir la page ou contacter le support si le problème persiste.
                    </p>
                    <pre className="bg-white/5 p-4 rounded-lg text-xs text-left overflow-auto max-w-full mb-6">
                        {this.state.error?.message || String(this.state.error)}
                    </pre>
                    <button 
                        onClick={() => window.location.reload()}
                        className="bg-white text-black px-6 py-3 rounded-lg font-bold"
                    >
                        Rafraîchir la page
                    </button>
                </div>
            );
        }

        return this.props.children;
    }
}

export default function App() {
    return (
        <ErrorBoundary>
            <AuthProvider>
                <Router>
                    <Routes>
                        <Route path="/login" element={<LoginView />} />
                        <Route path="/change-password" element={<ChangePasswordView />} />
                        <Route path="/" element={<PrivateRoute><DashboardView /></PrivateRoute>} />
                        <Route path="/admin/clients" element={<PrivateRoute><AdminClientsView /></PrivateRoute>} />
                        <Route path="/admin/clients/:id" element={<PrivateRoute><AdminClientDetailView /></PrivateRoute>} />
                        
                        {/* Modules */}
                        <Route path="/planning" element={<PrivateRoute><ModulePlaceholder title="Planning" icon={Calendar} /></PrivateRoute>} />
                        <Route path="/evenementiel" element={<PrivateRoute><EvenementielModule /></PrivateRoute>} />
                        <Route path="/crm" element={<PrivateRoute><CRMModule /></PrivateRoute>} />
                        <Route path="/factures" element={<PrivateRoute><ModulePlaceholder title="Factures" icon={FileText} /></PrivateRoute>} />
                        <Route path="/employes" element={<PrivateRoute><ModulePlaceholder title="Employés" icon={Users} /></PrivateRoute>} />
                        
                        {/* Fallback */}
                        <Route path="*" element={<Navigate to="/" />} />
                    </Routes>
                </Router>
            </AuthProvider>
        </ErrorBoundary>
    );
}
