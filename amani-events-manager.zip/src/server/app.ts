import { Hono } from 'hono';
import { cors } from 'hono/cors';
import { verify, sign } from 'hono/jwt';
import bcrypt from 'bcryptjs';
import { Resend } from 'resend';
import crypto from 'crypto';
import localDb from '../../database';
import 'dotenv/config';

// Type pour D1Database si les types Cloudflare ne sont pas chargés
interface D1Database {
    prepare(sql: string): any;
}

type Bindings = {
    DB: D1Database;
    JWT_SECRET: string;
    RESEND_API_KEY: string;
};

const app = new Hono<{
    Bindings: Bindings;
    Variables: {
        user: any;
    }
}>();

app.onError((err, c) => {
    console.error(`[CRITICAL APP ERROR] ${err.message}`, err.stack);
    return c.json({ error: 'Internal Server Error: ' + err.message }, 500);
});

const DEFAULT_JWT_SECRET = 'super-secret-key';
const SUPER_ADMIN_EMAIL = 'gev-emeni@outlook.fr';

app.use('/api/*', cors());

app.use('*', async (c, next) => {
    console.log(`[Hono Request] ${c.req.method} ${c.req.path}`);
    await next();
    console.log(`[Hono Response] ${c.req.method} ${c.req.path} -> ${c.res.status}`);
});

// Helper to get DB (D1 or Local)
const getDb = (c: any) => {
    if (c.env?.DB) {
        // Wrapper for D1 to match better-sqlite3 interface for simplicity in this refactor
        // In a real production app, we'd use a more robust abstraction or Drizzle ORM
        return {
            prepare: (sql: string) => ({
                get: async (...params: any[]) => (await c.env.DB.prepare(sql).bind(...params).first()),
                all: async (...params: any[]) => (await c.env.DB.prepare(sql).bind(...params).all()).results,
                run: async (...params: any[]) => (await c.env.DB.prepare(sql).bind(...params).run()),
            })
        };
    }
    return localDb;
};

// --- Middlewares ---

const authMiddleware = async (c: any, next: any) => {
    const authHeader = c.req.header('Authorization');
    if (!authHeader) return c.json({ error: 'Unauthorized' }, 401);
    
    const token = authHeader.split(' ')[1];
    try {
        const secret = c.env?.JWT_SECRET || process.env.JWT_SECRET || DEFAULT_JWT_SECRET;
        const payload = await verify(token, secret, 'HS256');
        c.set('user', payload);
        await next();
    } catch (e) {
        return c.json({ error: 'Invalid token' }, 401);
    }
};

const adminOnly = async (c: any, next: any) => {
    const user = c.get('user');
    if (user.type !== 'admin') return c.json({ error: 'Forbidden' }, 403);
    await next();
};

const superAdminOnly = async (c: any, next: any) => {
    const user = c.get('user');
    if (user.type !== 'admin' || user.email !== SUPER_ADMIN_EMAIL) {
        return c.json({ error: 'Super Admin access required' }, 403);
    }
    await next();
};

const moduleAccessMiddleware = async (c: any, next: any) => {
    const user = c.get('user');
    const db = getDb(c);
    const path = c.req.path;
    const moduleName = path.split('/')[2];
    
    console.log(`[DEBUG] Accessing module: ${moduleName} for path: ${path}, user type: ${user?.type}`);
    
    if (user.type === 'admin') {
        await next();
        return;
    }
    
    const clientModule = await db.prepare('SELECT is_active FROM client_modules WHERE client_id = ? AND module_name = ?')
                           .get(user.clientId, moduleName) as any;
    
    if (!clientModule || clientModule.is_active === 0) {
        return c.json({ error: 'Module not active for this client' }, 403);
    }
    
    if (user.type === 'collaborator') {
        const permission = await db.prepare('SELECT can_access FROM collaborator_permissions WHERE collaborator_id = ? AND module_name = ?')
                             .get(user.id, moduleName) as any;
        if (!permission || permission.can_access === 0) {
            return c.json({ error: 'Access denied to this module' }, 403);
        }
    }
    
    await next();
};

// --- Auth Routes ---

app.get('/api/health', (c) => {
    console.log('Health check requested');
    return c.json({ status: 'ok', timestamp: new Date().toISOString() });
});

app.post('/api/login', async (c) => {
    try {
        const { email, password } = await c.req.json();
        const db = getDb(c);
        
        console.log(`Login attempt for: ${email}`);
        
        // Check Admin
        let user = await db.prepare('SELECT * FROM admins WHERE email = ?').get(email) as any;
        let type = 'admin';
        
        if (!user) {
            user = await db.prepare('SELECT * FROM clients WHERE email = ?').get(email) as any;
            type = 'client';
        }
        
        if (!user) {
            user = await db.prepare('SELECT * FROM collaborators WHERE email = ?').get(email) as any;
            type = 'collaborator';
        }
        
        if (!user) {
            console.log(`User not found: ${email}`);
            return c.json({ error: 'Utilisateur non trouvé' }, 404);
        }
        
        // Check status for clients and collaborators
        if (type !== 'admin' && user.status === 'blocked') {
            return c.json({ error: 'Votre compte a été suspendu, contactez l\'administrateur' }, 403);
        }
        
        const valid = bcrypt.compareSync(password, user.password);
        if (!valid) {
            console.log(`Invalid password for: ${email}`);
            return c.json({ error: 'Mot de passe incorrect' }, 401);
        }

        // Update last login
        if (type === 'client') {
            try {
                await db.prepare('UPDATE clients SET last_login = CURRENT_TIMESTAMP WHERE id = ?').run(user.id);
            } catch (updateErr) {
                console.error('Failed to update last_login:', updateErr);
                // Continue anyway, login is more important than tracking
            }
        }
        
        const secret = c.env?.JWT_SECRET || process.env.JWT_SECRET || DEFAULT_JWT_SECRET;
        const payload = { 
            id: user.id, 
            email: user.email, 
            type,
            clientId: type === 'admin' ? null : (type === 'client' ? user.id : user.client_id),
            isTemporary: user.is_temporary_password === 1,
            exp: Math.floor(Date.now() / 1000) + 60 * 60 * 24 // 24h
        };
        
        const token = await sign(payload, secret, 'HS256');
        
        console.log(`Login successful for: ${email} (${type})`);
        return c.json({ 
            token, 
            user: { 
                id: user.id, 
                email: user.email, 
                type, 
                name: user.name || user.email,
                isTemporary: user.is_temporary_password === 1
            } 
        });
    } catch (e: any) {
        console.error('Login error:', e);
        return c.json({ error: 'Erreur interne du serveur: ' + e.message }, 500);
    }
});

app.get('/api/me', authMiddleware, async (c) => {
    const user = c.get('user');
    console.log(`[DEBUG] /api/me request for: ${user.email}, type: ${user.type}, id: ${user.id}`);
    const db = getDb(c);
    let userData;
    try {
        if (user.type === 'client') {
            userData = await db.prepare('SELECT id, name, email, status FROM clients WHERE id = ?').get(user.id);
        } else if (user.type === 'collaborator') {
            userData = await db.prepare('SELECT id, name, email, status FROM collaborators WHERE id = ?').get(user.id);
        } else {
            userData = await db.prepare('SELECT id, name, email FROM admins WHERE id = ?').get(user.id);
        }
        
        if (userData) {
            userData.type = user.type;
            console.log(`[DEBUG] Found user data: ${JSON.stringify(userData)}`);
        } else {
            console.warn(`[DEBUG] No user data found for id: ${user.id} in table for type: ${user.type}`);
        }
        
        return c.json(userData);
    } catch (err: any) {
        console.error(`[DEBUG] Error in /api/me: ${err.message}`);
        return c.json({ error: err.message }, 500);
    }
});

app.get('/api/me/modules', authMiddleware, async (c) => {
    const user = c.get('user');
    const db = getDb(c);
    
    if (user.type === 'admin') {
        // Admin has access to all modules conceptually, but doesn't use them
        return c.json([]);
    }
    
    const modules = await db.prepare('SELECT module_name, is_active FROM client_modules WHERE client_id = ?').all(user.clientId);
    return c.json(modules);
});

app.post('/api/change-password', authMiddleware, async (c) => {
    const { newPassword } = await c.req.json();
    const user = c.get('user');
    const db = getDb(c);
    const hashedPassword = bcrypt.hashSync(newPassword, 10);
    
    if (user.type === 'client') {
        await db.prepare('UPDATE clients SET password = ?, is_temporary_password = 0 WHERE id = ?').run(hashedPassword, user.id);
    } else if (user.type === 'collaborator') {
        await db.prepare('UPDATE collaborators SET password = ?, is_temporary_password = 0 WHERE id = ?').run(hashedPassword, user.id);
    } else {
        await db.prepare('UPDATE admins SET password = ? WHERE id = ?').run(hashedPassword, user.id);
    }
    
    return c.json({ success: true });
});

// --- Admin Routes ---

app.get('/api/admin/clients', authMiddleware, superAdminOnly, async (c) => {
    const db = getDb(c);
    const clients = await db.prepare('SELECT id, name, email, status, last_login, created_at FROM clients ORDER BY created_at DESC').all();
    return c.json(clients);
});

app.post('/api/admin/clients', authMiddleware, superAdminOnly, async (c) => {
    try {
        const { name, email, modules: selectedModules } = await c.req.json();
        const db = getDb(c);
        
        console.log(`Creating client: ${name} (${email})`);
        
        // Check if email already exists
        const existing = await db.prepare('SELECT id FROM clients WHERE email = ?').get(email);
        if (existing) {
            console.log(`Client creation failed: Email ${email} already exists`);
            return c.json({ error: 'Un client avec cet email existe déjà' }, 400);
        }
        
        const id = crypto.randomBytes(4).toString('hex');
        const tempPassword = crypto.randomBytes(4).toString('hex');
        const hashedPassword = bcrypt.hashSync(tempPassword, 10);
        
        console.log(`Generated ID: ${id}, Temp Password: ${tempPassword}`);
        
        try {
            await db.prepare('INSERT INTO clients (id, name, email, password, status) VALUES (?, ?, ?, ?, ?)').run(id, name, email, hashedPassword, 'active');
        } catch (dbErr: any) {
            console.error('Database error during client insert:', dbErr);
            throw new Error(`Erreur base de données: ${dbErr.message}`);
        }
        
        // Modules provisioning
        try {
            const allModules = ['planning', 'evenementiel', 'facture', 'employes', 'crm'];
            for (const m of allModules) {
                const isActive = selectedModules && selectedModules.includes(m) ? 1 : 0;
                await db.prepare('INSERT INTO client_modules (client_id, module_name, is_active) VALUES (?, ?, ?)').run(id, m, isActive);
            }
        } catch (modErr: any) {
            console.error('Database error during modules insert:', modErr);
            // We might want to rollback here in a real app, but for now we'll just log
        }

        console.log('Client and modules inserted successfully');

        // Send Email via Resend
        const resendKey = c.env?.RESEND_API_KEY || process.env.RESEND_API_KEY;
        if (resendKey) {
            console.log('Attempting to send welcome email...');
            const resend = new Resend(resendKey);
            try {
                await resend.emails.send({
                    from: 'Amani Platform <notification@l-iamani.com>',
                    to: email,
                    subject: 'Votre compte client Amani',
                    html: `
                        <div style="font-family: sans-serif; padding: 20px; color: #333;">
                            <h2 style="color: #000;">Bienvenue chez Amani</h2>
                            <p>Bonjour ${name},</p>
                            <p>Votre compte client a été créé avec succès. Voici vos identifiants temporaires :</p>
                            <div style="background: #f4f4f4; padding: 15px; border-radius: 8px; margin: 20px 0;">
                                <p style="margin: 5px 0;"><strong>Email :</strong> ${email}</p>
                                <p style="margin: 5px 0;"><strong>Mot de passe :</strong> ${tempPassword}</p>
                            </div>
                            <p>Vous devrez changer ce mot de passe lors de votre première connexion.</p>
                            <p>L'équipe Amani</p>
                        </div>
                    `
                });
                console.log('Welcome email sent successfully');
            } catch (emailErr) {
                console.error('Failed to send client email:', emailErr);
            }
        } else {
            console.log('No RESEND_API_KEY found, skipping email');
        }
        
        return c.json({ id, tempPassword });
    } catch (e: any) {
        console.error('Client creation error:', e);
        return c.json({ error: e.message }, 400);
    }
});

app.patch('/api/admin/clients/:id', authMiddleware, superAdminOnly, async (c) => {
    const id = c.req.param('id');
    const { name, email, status } = await c.req.json();
    const db = getDb(c);
    
    try {
        const updates = [];
        const params = [];
        if (name) { updates.push('name = ?'); params.push(name); }
        if (email) { updates.push('email = ?'); params.push(email); }
        if (status) { updates.push('status = ?'); params.push(status); }
        
        if (updates.length > 0) {
            params.push(id);
            await db.prepare(`UPDATE clients SET ${updates.join(', ')} WHERE id = ?`).run(...params);
        }
        return c.json({ success: true });
    } catch (e: any) {
        return c.json({ error: e.message }, 400);
    }
});

app.delete('/api/admin/clients/:id', authMiddleware, superAdminOnly, async (c) => {
    const id = c.req.param('id');
    const db = getDb(c);
    // Cascade delete is handled by foreign keys in schema
    await db.prepare('DELETE FROM clients WHERE id = ?').run(id);
    return c.json({ success: true });
});

app.post('/api/admin/clients/:id/reset-password', authMiddleware, superAdminOnly, async (c) => {
    const id = c.req.param('id');
    const db = getDb(c);
    const client = await db.prepare('SELECT name, email FROM clients WHERE id = ?').get(id) as any;
    if (!client) return c.json({ error: 'Client not found' }, 404);

    const tempPassword = crypto.randomUUID().substring(0, 8);
    const hashedPassword = bcrypt.hashSync(tempPassword, 10);
    await db.prepare('UPDATE clients SET password = ?, is_temporary_password = 1 WHERE id = ?').run(hashedPassword, id);

    const resendKey = c.env?.RESEND_API_KEY || process.env.RESEND_API_KEY;
    if (resendKey) {
        const resend = new Resend(resendKey);
        await resend.emails.send({
            from: 'Amani Platform <notification@l-iamani.com>',
            to: client.email,
            subject: 'Réinitialisation de votre mot de passe Amani',
            html: `
                <div style="font-family: sans-serif; padding: 20px; color: #333;">
                    <h2 style="color: #000;">Réinitialisation de mot de passe</h2>
                    <p>Bonjour ${client.name},</p>
                    <p>Votre mot de passe a été réinitialisé par l'administrateur. Voici vos nouveaux identifiants temporaires :</p>
                    <div style="background: #f4f4f4; padding: 15px; border-radius: 8px; margin: 20px 0;">
                        <p style="margin: 5px 0;"><strong>Email :</strong> ${client.email}</p>
                        <p style="margin: 5px 0;"><strong>Nouveau mot de passe :</strong> ${tempPassword}</p>
                    </div>
                    <p>Vous devrez changer ce mot de passe lors de votre prochaine connexion.</p>
                    <p>L'équipe Amani</p>
                </div>
            `
        });
    }

    return c.json({ success: true, tempPassword });
});

app.post('/api/admin/clients/:id/force-reset', authMiddleware, superAdminOnly, async (c) => {
    const id = c.req.param('id');
    const db = getDb(c);
    const client = await db.prepare('SELECT name, email FROM clients WHERE id = ?').get(id) as any;
    if (!client) return c.json({ error: 'Client not found' }, 404);

    const resetToken = crypto.randomUUID();
    const expires = new Date(Date.now() + 3600000).toISOString(); // 1h
    await db.prepare('UPDATE clients SET reset_token = ?, reset_token_expires = ? WHERE id = ?').run(resetToken, expires, id);

    const resendKey = c.env?.RESEND_API_KEY || process.env.RESEND_API_KEY;
    if (resendKey) {
        const resend = new Resend(resendKey);
        const resetLink = `${c.req.url.split('/api')[0]}/reset-password?token=${resetToken}`;
        await resend.emails.send({
            from: 'Amani Platform <notification@l-iamani.com>',
            to: client.email,
            subject: 'Réinitialisation de votre mot de passe Amani',
            html: `
                <div style="font-family: sans-serif; padding: 20px; color: #333;">
                    <h2 style="color: #000;">Réinitialisation de mot de passe</h2>
                    <p>Bonjour ${client.name},</p>
                    <p>Une réinitialisation de votre mot de passe a été forcée par l'administrateur.</p>
                    <p>Cliquez sur le lien ci-dessous pour définir votre nouveau mot de passe :</p>
                    <div style="margin: 30px 0;">
                        <a href="${resetLink}" style="background: #000; color: #fff; padding: 12px 24px; border-radius: 6px; text-decoration: none; font-weight: bold;">Réinitialiser mon mot de passe</a>
                    </div>
                    <p>Ce lien est valable pendant 1 heure.</p>
                    <p>L'équipe Amani</p>
                </div>
            `
        });
    }

    return c.json({ success: true });
});

app.post('/api/admin/clients/:id/impersonate', authMiddleware, superAdminOnly, async (c) => {
    const id = c.req.param('id');
    const db = getDb(c);
    const client = await db.prepare('SELECT * FROM clients WHERE id = ?').get(id) as any;
    if (!client) return c.json({ error: 'Client not found' }, 404);

    const secret = c.env?.JWT_SECRET || process.env.JWT_SECRET || DEFAULT_JWT_SECRET;
    const payload = { 
        id: client.id, 
        email: client.email, 
        type: 'client',
        clientId: client.id,
        isTemporary: false,
        exp: Math.floor(Date.now() / 1000) + 60 * 60 // 1h for impersonation
    };
    
    const token = await sign(payload, secret, 'HS256');
    return c.json({ token, user: { id: client.id, email: client.email, type: 'client', name: client.name } });
});

app.get('/api/admin/clients/:id/modules', authMiddleware, adminOnly, async (c) => {
    const clientId = c.req.param('id');
    const db = getDb(c);
    const modules = await db.prepare('SELECT module_name, is_active FROM client_modules WHERE client_id = ?').all(clientId);
    return c.json(modules);
});

app.post('/api/admin/clients/:id/modules', authMiddleware, adminOnly, async (c) => {
    const clientId = c.req.param('id');
    const { modules } = await c.req.json();
    const db = getDb(c);
    
    for (const m of modules) {
        await db.prepare('UPDATE client_modules SET is_active = ? WHERE client_id = ? AND module_name = ?')
          .run(m.active ? 1 : 0, clientId, m.name);
    }
    
    return c.json({ success: true });
});

app.get('/api/admin/stats', authMiddleware, superAdminOnly, async (c) => {
    const db = getDb(c);
    const clients = await db.prepare('SELECT COUNT(*) as count FROM clients').get() as any;
    const modules = await db.prepare('SELECT COUNT(*) as count FROM client_modules WHERE is_active = 1').get() as any;
    const collaborators = await db.prepare('SELECT COUNT(*) as count FROM collaborators').get() as any;
    
    return c.json({
        clientsCount: clients.count,
        activeModulesCount: modules.count,
        collaboratorsCount: collaborators.count,
        revenue: '12,450 €' // Dummy revenue for now
    });
});

app.get('/api/admin/clients/:id/collaborators', authMiddleware, adminOnly, async (c) => {
    const clientId = c.req.param('id');
    const db = getDb(c);
    const collaborators = await db.prepare('SELECT id, name, email, role, created_at FROM collaborators WHERE client_id = ?').all(clientId);
    return c.json(collaborators);
});

app.post('/api/admin/clients/:id/collaborators', authMiddleware, adminOnly, async (c) => {
    const clientId = c.req.param('id');
    const { name, email, role } = await c.req.json();
    const db = getDb(c);
    const id = crypto.randomUUID().substring(0, 8);
    const tempPassword = crypto.randomUUID().substring(0, 8);
    const hashedPassword = bcrypt.hashSync(tempPassword, 10);
    
    try {
        await db.prepare('INSERT INTO collaborators (id, client_id, name, email, password, role) VALUES (?, ?, ?, ?, ?, ?)')
          .run(id, clientId, name, email, hashedPassword, role);
        
        // Default permissions
        const modules = ['planning', 'evenementiel', 'facture', 'employes', 'crm'];
        for (const m of modules) {
            await db.prepare('INSERT INTO collaborator_permissions (collaborator_id, module_name, can_access) VALUES (?, ?, 0)').run(id, m);
        }

        // Send Email via Resend
        const resendKey = c.env?.RESEND_API_KEY || process.env.RESEND_API_KEY;
        if (resendKey) {
            const resend = new Resend(resendKey);
            try {
                await resend.emails.send({
                    from: 'Amani Platform <notification@l-iamani.com>',
                    to: email,
                    subject: 'Vos accès collaborateur Amani',
                    html: `
                        <div style="font-family: sans-serif; padding: 20px; color: #333;">
                            <h2 style="color: #000;">Accès Collaborateur</h2>
                            <p>Bonjour ${name},</p>
                            <p>Un compte collaborateur vous a été créé. Voici vos accès :</p>
                            <div style="background: #f4f4f4; padding: 15px; border-radius: 8px; margin: 20px 0;">
                                <p style="margin: 5px 0;"><strong>Email :</strong> ${email}</p>
                                <p style="margin: 5px 0;"><strong>Mot de passe :</strong> ${tempPassword}</p>
                            </div>
                            <p>L'équipe Amani</p>
                        </div>
                    `
                });
            } catch (emailErr) {
                console.error('Failed to send collaborator email:', emailErr);
            }
        }
        
        return c.json({ id, tempPassword });
    } catch (e: any) {
        return c.json({ error: e.message }, 400);
    }
});

// --- Module Routes ---

app.get('/api/planning', authMiddleware, moduleAccessMiddleware, async (c) => {
    const user = c.get('user');
    const db = getDb(c);
    const items = await db.prepare('SELECT * FROM planning WHERE client_id = ?').all(user.clientId);
    return c.json(items);
});

// --- Evenementiel Calendars ---

app.get('/api/evenementiel/spaces', authMiddleware, moduleAccessMiddleware, async (c) => {
    try {
        const user = c.get('user');
        const db = getDb(c);
        const query = user.type === 'admin' 
            ? 'SELECT * FROM evenementiel_spaces ORDER BY name ASC' 
            : 'SELECT * FROM evenementiel_spaces WHERE client_id = ? ORDER BY name ASC';
        const params = user.type === 'admin' ? [] : [user.clientId];
        const items = await db.prepare(query).all(...params);
        return c.json(items);
    } catch (e: any) {
        console.error('Error fetching spaces:', e);
        return c.json({ error: e.message }, 500);
    }
});

app.get('/api/admin/clients/:id/spaces', authMiddleware, superAdminOnly, async (c) => {
    const clientId = c.req.param('id');
    const db = getDb(c);
    const items = await db.prepare('SELECT * FROM evenementiel_spaces WHERE client_id = ? ORDER BY name ASC').all(clientId);
    return c.json(items);
});

app.post('/api/admin/clients/:id/spaces', authMiddleware, superAdminOnly, async (c) => {
    const clientId = c.req.param('id');
    const db = getDb(c);
    const { name, color } = await c.req.json();
    const id = crypto.randomUUID().substring(0, 8);

    try {
        await db.prepare('INSERT INTO evenementiel_spaces (id, client_id, name, color) VALUES (?, ?, ?, ?)').run(id, clientId, name, color);
        return c.json({ id });
    } catch (e: any) {
        return c.json({ error: e.message }, 400);
    }
});

app.delete('/api/admin/clients/:clientId/spaces/:spaceId', authMiddleware, superAdminOnly, async (c) => {
    const { spaceId } = c.req.param();
    const db = getDb(c);
    await db.prepare('DELETE FROM evenementiel_spaces WHERE id = ?').run(spaceId);
    return c.json({ success: true });
});

app.get('/api/admin/clients/:id/staff-types', authMiddleware, superAdminOnly, async (c) => {
    const clientId = c.req.param('id');
    const db = getDb(c);
    const items = await db.prepare('SELECT * FROM evenementiel_staff_types WHERE client_id = ? ORDER BY name ASC').all(clientId);
    return c.json(items);
});

app.post('/api/admin/clients/:id/staff-types', authMiddleware, superAdminOnly, async (c) => {
    const clientId = c.req.param('id');
    const db = getDb(c);
    const { name } = await c.req.json();
    const id = crypto.randomUUID().substring(0, 8);

    try {
        await db.prepare('INSERT INTO evenementiel_staff_types (id, client_id, name) VALUES (?, ?, ?)').run(id, clientId, name);
        return c.json({ id });
    } catch (e: any) {
        return c.json({ error: e.message }, 400);
    }
});

app.delete('/api/admin/clients/:clientId/staff-types/:staffId', authMiddleware, superAdminOnly, async (c) => {
    const { staffId } = c.req.param();
    const db = getDb(c);
    await db.prepare('DELETE FROM evenementiel_staff_types WHERE id = ?').run(staffId);
    return c.json({ success: true });
});

app.get('/api/evenementiel/staff-types', authMiddleware, moduleAccessMiddleware, async (c) => {
    try {
        const user = c.get('user');
        const db = getDb(c);
        const query = user.type === 'admin' 
            ? 'SELECT * FROM evenementiel_staff_types ORDER BY name ASC' 
            : 'SELECT * FROM evenementiel_staff_types WHERE client_id = ? ORDER BY name ASC';
        const params = user.type === 'admin' ? [] : [user.clientId];
        const items = await db.prepare(query).all(...params);
        return c.json(items);
    } catch (e: any) {
        console.error('Error fetching staff types:', e);
        return c.json({ error: e.message }, 500);
    }
});

app.post('/api/evenementiel/staff-types', authMiddleware, moduleAccessMiddleware, async (c) => {
    const user = c.get('user');
    const db = getDb(c);
    const body = await c.req.json();
    const { name } = body;
    const clientId = user.type === 'admin' ? (body.client_id || user.clientId) : user.clientId;
    const id = crypto.randomUUID().substring(0, 8);

    try {
        await db.prepare('INSERT INTO evenementiel_staff_types (id, client_id, name) VALUES (?, ?, ?)').run(id, clientId, name);
        return c.json({ id });
    } catch (e: any) {
        return c.json({ error: e.message }, 400);
    }
});

app.delete('/api/evenementiel/staff-types/:id', authMiddleware, moduleAccessMiddleware, async (c) => {
    const user = c.get('user');
    const db = getDb(c);
    const id = c.req.param('id');
    if (user.type === 'admin') {
        await db.prepare('DELETE FROM evenementiel_staff_types WHERE id = ?').run(id);
    } else {
        await db.prepare('DELETE FROM evenementiel_staff_types WHERE id = ? AND client_id = ?').run(id, user.clientId);
    }
    return c.json({ success: true });
});

app.get('/api/evenementiel/calendars', authMiddleware, moduleAccessMiddleware, async (c) => {
    try {
        const user = c.get('user');
        const db = getDb(c);
        
        if (user.type !== 'admin') {
            const now = new Date();
            const currentMonth = now.getMonth() + 1;
            const currentYear = now.getFullYear();
            await db.prepare(`
                UPDATE evenementiel_calendars 
                SET status = 'ARCHIVED' 
                WHERE client_id = ? 
                AND status = 'OPEN' 
                AND (year < ? OR (year = ? AND month < ?))
            `).run(user.clientId, currentYear, currentYear, currentMonth);
        }

        const query = user.type === 'admin' 
            ? 'SELECT * FROM evenementiel_calendars ORDER BY year ASC, month ASC' 
            : 'SELECT * FROM evenementiel_calendars WHERE client_id = ? ORDER BY year ASC, month ASC';
        const params = user.type === 'admin' ? [] : [user.clientId];
        const items = await db.prepare(query).all(...params);
        return c.json(items);
    } catch (e: any) {
        console.error('Error fetching calendars:', e);
        return c.json({ error: e.message }, 500);
    }
});

app.post('/api/evenementiel/calendars', authMiddleware, moduleAccessMiddleware, async (c) => {
    const user = c.get('user');
    const db = getDb(c);
    const body = await c.req.json();
    const { month, year } = body;
    const clientId = user.type === 'admin' ? (body.client_id || user.clientId) : user.clientId;
    const id = crypto.randomUUID().substring(0, 8);

    try {
        await db.prepare('INSERT INTO evenementiel_calendars (id, client_id, month, year) VALUES (?, ?, ?, ?)').run(id, clientId, month, year);
        return c.json({ id });
    } catch (e: any) {
        return c.json({ error: e.message }, 400);
    }
});

app.get('/api/evenementiel/calendars/:id/events', authMiddleware, moduleAccessMiddleware, async (c) => {
    try {
        const user = c.get('user');
        const db = getDb(c);
        const calendarId = c.req.param('id');
        
        const query = user.type === 'admin'
            ? 'SELECT e.*, (SELECT COUNT(*) FROM evenementiel_event_assignments WHERE event_id = e.id) as assigned_count FROM evenementiel e WHERE e.calendar_id = ? ORDER BY e.start_time ASC'
            : 'SELECT e.*, (SELECT COUNT(*) FROM evenementiel_event_assignments WHERE event_id = e.id) as assigned_count FROM evenementiel e WHERE e.calendar_id = ? AND e.client_id = ? ORDER BY e.start_time ASC';
        const params = user.type === 'admin' ? [calendarId] : [calendarId, user.clientId];
        
        const events = await db.prepare(query).all(...params);
        
        // Fetch spaces and staff for each event
        const enrichedEvents = await Promise.all(events.map(async (event: any) => {
            const spaces = await db.prepare(`
                SELECT s.* FROM evenementiel_spaces s
                JOIN evenementiel_event_spaces es ON s.id = es.space_id
                WHERE es.event_id = ?
            `).all(event.id);
            
            const staff = await db.prepare(`
                SELECT st.name, est.count, st.id as staff_type_id FROM evenementiel_staff_types st
                JOIN evenementiel_event_staff est ON st.id = est.staff_type_id
                WHERE est.event_id = ?
            `).all(event.id);

            const assignments = await db.prepare(`
                SELECT e.first_name || ' ' || e.last_name as employee_name, st.name as staff_type_name, st.id as staff_type_id
                FROM evenementiel_event_assignments a
                JOIN employes e ON a.employee_id = e.id
                JOIN evenementiel_staff_types st ON a.staff_type_id = st.id
                WHERE a.event_id = ?
            `).all(event.id);
            
            return { ...event, spaces, staff, assignments };
        }));

        return c.json(enrichedEvents);
    } catch (e: any) {
        console.error('Error fetching calendar events:', e);
        return c.json({ error: e.message }, 500);
    }
});

app.get('/api/evenementiel', authMiddleware, moduleAccessMiddleware, async (c) => {
    try {
        const user = c.get('user');
        const db = getDb(c);
        // Super admin sees everything, others only their client data
        const query = user.type === 'admin' 
            ? 'SELECT * FROM evenementiel ORDER BY start_time DESC' 
            : 'SELECT * FROM evenementiel WHERE client_id = ? ORDER BY start_time DESC';
        const params = user.type === 'admin' ? [] : [user.clientId];
        const items = await db.prepare(query).all(...params);

        const enrichedEvents = await Promise.all(items.map(async (event: any) => {
            const spaces = await db.prepare(`
                SELECT s.name, s.color FROM evenementiel_spaces s
                JOIN evenementiel_event_spaces es ON s.id = es.space_id
                WHERE es.event_id = ?
            `).all(event.id);
            
            const staff = await db.prepare(`
                SELECT st.name, est.count, st.id as staff_type_id FROM evenementiel_staff_types st
                JOIN evenementiel_event_staff est ON st.id = est.staff_type_id
                WHERE est.event_id = ?
            `).all(event.id);

            const assignments = await db.prepare(`
                SELECT e.first_name || ' ' || e.last_name as employee_name, st.name as staff_type_name, st.id as staff_type_id
                FROM evenementiel_event_assignments a
                JOIN employes e ON a.employee_id = e.id
                JOIN evenementiel_staff_types st ON a.staff_type_id = st.id
                WHERE a.event_id = ?
            `).all(event.id);
            
            return { ...event, spaces, staff, assignments };
        }));

        return c.json(enrichedEvents);
    } catch (e: any) {
        console.error('Error fetching evenementiel:', e);
        return c.json({ error: e.message }, 500);
    }
});

app.post('/api/evenementiel', authMiddleware, moduleAccessMiddleware, async (c) => {
    const user = c.get('user');
    const db = getDb(c);
    const body = await c.req.json();
    const id = crypto.randomUUID().substring(0, 8);
    
    const { 
        calendar_id, type, phone, email, address, start_time, end_time, num_people, 
        staff_requests, assignments, documents, first_name, last_name, company_name, organizer_name,
        space_ids
    } = body;

    if (!calendar_id) return c.json({ error: 'Calendar ID is required' }, 400);
    if (!space_ids || space_ids.length === 0) return c.json({ error: 'At least one space is required' }, 400);

    const clientId = user.type === 'admin' ? (body.client_id || user.clientId) : user.clientId;

    try {
        // Check if calendar is OPEN
        const calendar = await db.prepare('SELECT status FROM evenementiel_calendars WHERE id = ? AND client_id = ?').get(calendar_id, clientId);
        if (!calendar) return c.json({ error: 'Calendar not found' }, 404);
        if (calendar.status === 'ARCHIVED') return c.json({ error: 'Cannot add events to an archived calendar' }, 403);

        // 1. Insert Event
        await db.prepare(`
            INSERT INTO evenementiel (
                id, client_id, calendar_id, type, phone, email, address, start_time, end_time, 
                num_people, documents, first_name, last_name, 
                company_name, organizer_name
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `).run(
            id, clientId, calendar_id, type, phone, email, address, start_time, end_time, 
            num_people, JSON.stringify(documents || []), 
            first_name, last_name, company_name, organizer_name
        );

        // 2. Insert spaces
        for (const spaceId of space_ids) {
            await db.prepare('INSERT INTO evenementiel_event_spaces (event_id, space_id) VALUES (?, ?)').run(id, spaceId);
        }

        // 3. Insert staff requests (staff_requests is an object: { staff_type_id: count })
        if (staff_requests && typeof staff_requests === 'object') {
            for (const [staffTypeId, count] of Object.entries(staff_requests)) {
                if (Number(count) > 0) {
                    await db.prepare('INSERT INTO evenementiel_event_staff (event_id, staff_type_id, count) VALUES (?, ?, ?)').run(id, staffTypeId, count);
                }
            }
        }

        // 4. Insert assignments (internal booking)
        if (assignments && Array.isArray(assignments)) {
            for (const ass of assignments) {
                await db.prepare('INSERT INTO evenementiel_event_assignments (event_id, employee_id, staff_type_id) VALUES (?, ?, ?)').run(id, ass.employee_id, ass.staff_type_id);
            }
        }

        // 5. CRM Logic: Automatic Contact Management
        const existingContact = await db.prepare('SELECT id FROM crm_contacts WHERE client_id = ? AND phone = ?').get(clientId, phone);
        if (existingContact) {
            await db.prepare(`
                UPDATE crm_contacts 
                SET type = ?, first_name = ?, last_name = ?, company_name = ?, organizer_name = ?, email = ?, updated_at = CURRENT_TIMESTAMP
                WHERE id = ?
            `).run(type, first_name, last_name, company_name, organizer_name, email, existingContact.id);
        } else {
            const contactId = crypto.randomUUID().substring(0, 8);
            await db.prepare(`
                INSERT INTO crm_contacts (id, client_id, type, first_name, last_name, company_name, organizer_name, email, phone)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            `).run(contactId, clientId, type, first_name, last_name, company_name, organizer_name, email, phone);
        }

        return c.json({ id });
    } catch (e: any) {
        console.error('Event creation error:', e);
        return c.json({ error: e.message }, 400);
    }
});

app.delete('/api/evenementiel/:id', authMiddleware, moduleAccessMiddleware, async (c) => {
    const user = c.get('user');
    const db = getDb(c);
    const id = c.req.param('id');

    if (user.type === 'admin') {
        await db.prepare('DELETE FROM evenementiel WHERE id = ?').run(id);
    } else {
        await db.prepare('DELETE FROM evenementiel WHERE id = ? AND client_id = ?').run(id, user.clientId);
    }
    return c.json({ success: true });
});

app.get('/api/crm/contacts', authMiddleware, moduleAccessMiddleware, async (c) => {
    try {
        const user = c.get('user');
        const db = getDb(c);
        const items = await db.prepare('SELECT * FROM crm_contacts WHERE client_id = ? ORDER BY updated_at DESC').all(user.clientId);
        return c.json(items);
    } catch (e: any) {
        console.error('Error fetching CRM contacts:', e);
        return c.json({ error: e.message }, 500);
    }
});

app.get('/api/crm/contacts/:id', authMiddleware, moduleAccessMiddleware, async (c) => {
    try {
        const user = c.get('user');
        const db = getDb(c);
        const id = c.req.param('id');
        
        const contact = await db.prepare('SELECT * FROM crm_contacts WHERE id = ? AND client_id = ?').get(id, user.clientId);
        if (!contact) return c.json({ error: 'Contact not found' }, 404);
        
        // Get history
        const history = await db.prepare(`
            SELECT e.*, GROUP_CONCAT(s.name) as spaces
            FROM evenementiel e
            LEFT JOIN evenementiel_event_spaces es ON e.id = es.event_id
            LEFT JOIN evenementiel_spaces s ON es.space_id = s.id
            WHERE e.client_id = ? AND e.phone = ?
            GROUP BY e.id
            ORDER BY e.start_time DESC
        `).all(user.clientId, contact.phone);
        
        return c.json({ ...contact, history });
    } catch (e: any) {
        console.error('Error fetching CRM contact detail:', e);
        return c.json({ error: e.message }, 500);
    }
});

app.get('/api/facture', authMiddleware, moduleAccessMiddleware, async (c) => {
    try {
        const user = c.get('user');
        const db = getDb(c);
        const items = await db.prepare('SELECT * FROM facture WHERE client_id = ?').all(user.clientId);
        return c.json(items);
    } catch (e: any) {
        console.error('Error fetching factures:', e);
        return c.json({ error: e.message }, 500);
    }
});

app.get('/api/employes', authMiddleware, moduleAccessMiddleware, async (c) => {
    try {
        const user = c.get('user');
        const db = getDb(c);
        const items = await db.prepare('SELECT * FROM employes WHERE client_id = ?').all(user.clientId);
        return c.json(items);
    } catch (e: any) {
        console.error('Error fetching employes:', e);
        return c.json({ error: e.message }, 500);
    }
});

export default app;
