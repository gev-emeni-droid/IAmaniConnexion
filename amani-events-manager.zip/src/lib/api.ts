const API_URL = '/api';

export async function apiFetch(endpoint: string, options: RequestInit = {}) {
    const token = localStorage.getItem('token');
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 10000); // 10s timeout

    const headers = {
        'Content-Type': 'application/json',
        ...(token ? { 'Authorization': `Bearer ${token}` } : {}),
        ...options.headers,
    };

    try {
        const response = await fetch(`${API_URL}${endpoint}`, { 
            ...options, 
            headers,
            signal: controller.signal 
        });
        clearTimeout(timeoutId);
        
        let data;
        const contentType = response.headers.get('content-type');
        if (contentType && contentType.includes('application/json')) {
            data = await response.json();
        } else {
            const text = await response.text();
            data = { error: text || 'Non-JSON response received' };
        }

        if (!response.ok) {
            throw new Error(data.error || `Error ${response.status}: ${response.statusText}`);
        }

        return data;
    } catch (error: any) {
        clearTimeout(timeoutId);
        if (error.name === 'AbortError') {
            throw new Error('La requête a expiré (timeout)');
        }
        throw error;
    }
}

export const authApi = {
    login: (credentials: any) => apiFetch('/login', { method: 'POST', body: JSON.stringify(credentials) }),
    changePassword: (newPassword: string) => apiFetch('/change-password', { method: 'POST', body: JSON.stringify({ newPassword }) }),
    getMe: () => apiFetch('/me'),
    getMyModules: () => apiFetch('/me/modules'),
};

export const adminApi = {
    getStats: () => apiFetch('/admin/stats'),
    getClients: () => apiFetch('/admin/clients'),
    createClient: (client: any) => apiFetch('/admin/clients', { method: 'POST', body: JSON.stringify(client) }),
    updateClient: (id: string, data: any) => apiFetch(`/admin/clients/${id}`, { method: 'PATCH', body: JSON.stringify(data) }),
    deleteClient: (id: string) => apiFetch(`/admin/clients/${id}`, { method: 'DELETE' }),
    resetClientPassword: (id: string) => apiFetch(`/admin/clients/${id}/reset-password`, { method: 'POST' }),
    forceResetClientPassword: (id: string) => apiFetch(`/admin/clients/${id}/force-reset`, { method: 'POST' }),
    impersonateClient: (id: string) => apiFetch(`/admin/clients/${id}/impersonate`, { method: 'POST' }),
    getClientModules: (id: string) => apiFetch(`/admin/clients/${id}/modules`),
    updateClientModules: (id: string, modules: any) => apiFetch(`/admin/clients/${id}/modules`, { method: 'POST', body: JSON.stringify({ modules }) }),
    getCollaborators: (clientId: string) => apiFetch(`/admin/clients/${clientId}/collaborators`),
    createCollaborator: (clientId: string, collaborator: any) => apiFetch(`/admin/clients/${clientId}/collaborators`, { method: 'POST', body: JSON.stringify(collaborator) }),
    getSpaces: (id: string) => apiFetch(`/admin/clients/${id}/spaces`),
    createSpace: (id: string, space: any) => apiFetch(`/admin/clients/${id}/spaces`, { method: 'POST', body: JSON.stringify(space) }),
    deleteSpace: (clientId: string, spaceId: string) => apiFetch(`/admin/clients/${clientId}/spaces/${spaceId}`, { method: 'DELETE' }),
    getStaffTypes: (id: string) => apiFetch(`/admin/clients/${id}/staff-types`),
    createStaffType: (id: string, staff: any) => apiFetch(`/admin/clients/${id}/staff-types`, { method: 'POST', body: JSON.stringify(staff) }),
    deleteStaffType: (clientId: string, staffId: string) => apiFetch(`/admin/clients/${clientId}/staff-types/${staffId}`, { method: 'DELETE' }),
};

export const moduleApi = {
    getPlanning: () => apiFetch('/planning'),
    getEvenementiel: () => apiFetch('/evenementiel'),
    getEvenementielCalendars: () => apiFetch('/evenementiel/calendars'),
    createEvenementielCalendar: (calendar: any) => apiFetch('/evenementiel/calendars', { method: 'POST', body: JSON.stringify(calendar) }),
    getEvenementielCalendarEvents: (id: string) => apiFetch(`/evenementiel/calendars/${id}/events`),
    getEvenementielSpaces: () => apiFetch('/evenementiel/spaces'),
    getEvenementielStaffTypes: () => apiFetch('/evenementiel/staff-types'),
    createEvenementielStaffType: (data: any) => apiFetch('/evenementiel/staff-types', { method: 'POST', body: JSON.stringify(data) }),
    deleteEvenementielStaffType: (id: string) => apiFetch(`/evenementiel/staff-types/${id}`, { method: 'DELETE' }),
    createEvenementiel: (event: any) => apiFetch('/evenementiel', { method: 'POST', body: JSON.stringify(event) }),
    deleteEvenementiel: (id: string) => apiFetch(`/evenementiel/${id}`, { method: 'DELETE' }),
    getCRMContacts: () => apiFetch('/crm/contacts'),
    getCRMContact: (id: string) => apiFetch(`/crm/contacts/${id}`),
    getFacture: () => apiFetch('/facture'),
    getEmployes: () => apiFetch('/employes'),
};
