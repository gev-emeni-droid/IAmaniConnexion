import Database from 'better-sqlite3';
import fs from 'fs';
import path from 'path';
import bcrypt from 'bcryptjs';
import crypto from 'crypto';

// Interface pour supporter D1 en production et better-sqlite3 en dev
export interface DatabaseInstance {
    prepare(sql: string): {
        get(...params: any[]): any;
        all(...params: any[]): any[];
        run(...params: any[]): { lastInsertRowid: number | bigint; changes: number };
    };
    exec(sql: string): void;
}

const dbPath = path.join(process.cwd(), 'database.sqlite');
const db = new Database(dbPath);

// Migrations for existing tables (run before schema to ensure columns exist for indexes)
try {
    db.prepare('ALTER TABLE evenementiel ADD COLUMN calendar_id TEXT').run();
} catch (e) {}

try {
    db.prepare('ALTER TABLE employes ADD COLUMN tags TEXT').run();
} catch (e) {}

// Initialize database with schema
const schema = fs.readFileSync(path.join(process.cwd(), 'schema.sql'), 'utf8');
db.exec(schema);

// Seed Super Admin if not exists
const superAdminEmail = 'gev-emeni@outlook.fr';
const existingAdmin = db.prepare('SELECT * FROM admins WHERE email = ?').get(superAdminEmail);

if (!existingAdmin) {
    const id = crypto.randomUUID().substring(0, 8);
    // Mot de passe par défaut: Amani2024! (À changer immédiatement)
    const hashedPassword = bcrypt.hashSync('Amani2024!', 10);
    db.prepare('INSERT INTO admins (id, email, password, name) VALUES (?, ?, ?, ?)')
      .run(id, superAdminEmail, hashedPassword, 'Super Admin');
    console.log('Super Admin seeded with default password: Amani2024!');
}

export default db as unknown as DatabaseInstance;
